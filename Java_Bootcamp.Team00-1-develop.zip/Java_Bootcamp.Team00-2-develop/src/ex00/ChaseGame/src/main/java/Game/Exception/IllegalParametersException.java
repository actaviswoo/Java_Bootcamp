package Game.Exception;

public class IllegalParametersException extends RuntimeException {
    public IllegalParametersException(String msg) {
        super(msg);
    }
}
