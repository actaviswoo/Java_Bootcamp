ChaseGame by danyellt, ehtelfos and argoniaz

0. install maven
1. type "sh install.sh"
2. usage: java -jar game.jar --enemiesCount=10 --wallsCount=10 --size=30 --profile=production
4. in order to delete the game, execute "sh uninstall.sh" twice