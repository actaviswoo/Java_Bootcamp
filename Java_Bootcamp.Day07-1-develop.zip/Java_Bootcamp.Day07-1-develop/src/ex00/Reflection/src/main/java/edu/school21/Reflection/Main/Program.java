package edu.school21.Reflection.Main;

import org.reflections.Reflections;
import org.reflections.scanners.SubTypesScanner;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Set;

public class Program {
    private static final String DELIMITER = "----------------------------";
    private static Set<Class<?>> classes;
    private static Class<?> class_;
    private static Field[] fields;
    private static Method[] methods;
    private static Object object;
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        fillClasses();
        inputClass();
        fillFields();
        fillMethods();
        fillObject();
        changeObject();
        callMethods();
    }

    public static void fillClasses() {
        System.out.println("Classes: ");
        Reflections reflections = new Reflections("edu.school21.Reflection.Classes", new SubTypesScanner(false));
        classes = reflections.getSubTypesOf(Object.class);
        for(Class<?> i : classes) {
            System.out.println("- " + i.getSimpleName());
        }
        System.out.println(DELIMITER);
    }

    public static void inputClass() {
        System.out.print("Enter class name:\n-> ");
        String input = "";
        if(!scanner.hasNext()) {
            System.err.println("Illegal argument!");
            System.exit(-1);
        } else {
            input = scanner.nextLine();
            for (Class<?> c : classes) {
                if (c.getSimpleName().equals(input)) {
                    class_ = c;
                    System.out.println("Class '" + class_.getSimpleName() + "' selected");
                    System.out.println(DELIMITER);
                    return;
                }
            }
            System.err.println("Class '" + input + "' doesn't exist");
            System.exit(-1);
        }
    }

    public static void fillFields() {
        System.out.println("Fields:");
        fields = class_.getDeclaredFields();
        for (Field field : fields) {
            System.out.println("\t" + field.getType().getSimpleName() + " " + field.getName());
        }
    }

    public static void fillMethods() {
        System.out.println("Methods:");
        methods = class_.getDeclaredMethods();
        for (Method method : methods) {
            System.out.println("\t" + method.getReturnType().getSimpleName() + " " + method.getName() + "(" + methodParameters(method) +")");
        }
        System.out.println(DELIMITER);
    }

    public static String methodParameters(Method method) {
        Class<?>[] parameterTypes = method.getParameterTypes();
        String methodStr = "";
        if(parameterTypes.length > 0) {
            for (int i = 0; i < parameterTypes.length; i++) {
                if (i != parameterTypes.length - 1) {
                    methodStr += (parameterTypes[i].getSimpleName() + ", ");
                } else {
                    methodStr += (parameterTypes[i].getSimpleName());
                }
            }
        }
        return methodStr;
    }

    public static void fillObject() {
        System.out.println("Let’s create an object.");
        try {
            object = Class.forName(class_.getName()).newInstance();
        } catch (ClassNotFoundException | InstantiationException | NullPointerException | IllegalAccessException exception) {
            System.err.println("Can't init object");
            System.exit(-1);
        }
        for (Field field : fields) {
            System.out.print(field.getName() + ":\n-> ");
            if(!scanner.hasNext()) {
                System.err.println("Illegal argument!");
                System.exit(-1);
            }
            field.setAccessible(true);
            Class<?> fieldType = field.getType();
            String inputValue = scanner.nextLine();
            setObject(fieldType, inputValue, field);
        }
        System.out.println("Object created: " + object + "\n" + DELIMITER);
    }

    public static void changeObject() {
        System.out.print("Enter name of the field for changing:\n-> ");
        if(!scanner.hasNext()) {
            System.err.println("Illegal argument!");
            System.exit(-1);
        }
        String variable = scanner.nextLine();
        for (Field field : fields) {
            if (field.getName().equals(variable)) {
                System.out.print("Enter String value:\n-> ");
                field.setAccessible(true);
                Class<?> fieldType = field.getType();
                String inputValue = scanner.nextLine();
                setObject(fieldType, inputValue, field);
                System.out.println("Object updated: " + object + "\n" + DELIMITER);
            }
        }
    }

    public static void setObject(Class<?> fieldType, String inputValue, Field field) {
        try {
            if (fieldType == Integer.class || fieldType == int.class) {
                field.set(object, Integer.parseInt(inputValue));
            } else if (fieldType == String.class) {
                field.set(object, inputValue);
            } else if (fieldType == Double.class || fieldType == double.class) {
                field.set(object, Double.parseDouble(inputValue));
            } else if (fieldType == Long.class || fieldType == long.class) {
                field.set(object, Long.parseLong(inputValue));
            } else if (fieldType == Float.class || fieldType == float.class) {
                field.set(object, Float.parseFloat(inputValue));
            } else if (fieldType == Boolean.class || fieldType == boolean.class) {
                field.set(object, Boolean.parseBoolean(inputValue));
            }
        } catch (IllegalAccessException exception) {
            System.err.println("Can't change");
            System.exit(-1);
        }
    }

    public static void callMethods() {
        System.out.print("Enter name of the method for call:\n-> ");
        if(!scanner.hasNext()) {
            System.err.println("Illegal argument!");
            System.exit(-1);
        }
        String variable = scanner.nextLine();
        for(Method method : methods) {
            if ((method.getReturnType().getSimpleName() + " " + method.getName() + "(" + methodParameters(method) + ")").equals(variable)) {
                method.setAccessible(true);
                ArrayList<Object> objects = new ArrayList<>();
                for (Class<?> param : method.getParameterTypes()) {
                    if (param == Integer.class || param == int.class) {
                        System.out.print("Enter " + Integer.class.getSimpleName() + " value:\n-> ");
                        int variableInt = scanner.nextInt();
                        objects.add(variableInt);
                    } else if (param == String.class) {
                        System.out.print("Enter " + String.class.getSimpleName() + " value:\n-> ");
                        String variableStr = scanner.nextLine();
                        objects.add(variableStr);
                    } else if (param == Double.class || param == double.class) {
                        System.out.print("Enter " + Double.class.getSimpleName() + " value:\n-> ");
                        double variableDouble = scanner.nextDouble();
                        objects.add(variableDouble);
                    } else if (param == Boolean.class || param == boolean.class) {
                        System.out.print("Enter " + Boolean.class.getSimpleName() + " value:\n-> ");
                        boolean variableBool = scanner.nextBoolean();
                        objects.add(variableBool);
                    } else if (param == Float.class || param == float.class) {
                        System.out.print("Enter " + Float.class.getSimpleName() + " value:\n-> ");
                        float variableFloat = scanner.nextFloat();
                        objects.add(variableFloat);
                    } else if (param == Long.class || param == long.class) {
                        System.out.print("Enter " + Long.class.getSimpleName() + " value:\n-> ");
                        long variableLong = scanner.nextLong();
                        objects.add(variableLong);
                    }
                }
                try {
                    Object[] arguments = objects.toArray(new Object[0]);
                    System.out.println("Method returned:");
                    if (method.getReturnType().getSimpleName().equals("void")) {
                        method.invoke(object, arguments);
                    } else {
                        System.out.println(method.invoke(object, arguments));
                    }
                } catch (NullPointerException | IllegalAccessException | InvocationTargetException exception) {
                    System.out.println("Class doesn't exist");
                    System.exit(-1);
                }
            }
        }
    }

}

