package edu.school21.Reflection.Classes;

import java.util.StringJoiner;

public class Car {
    private String brand;
    private String model;
    private String color;

    public Car() {
        this.brand = "mercedes benz";
        this.model = "g-class";
        this.color = "black";
    }

    public Car(String brand, String model, String color) {
        this.brand = brand;
        this.model = model;
        this.color = color;
    }

    public void changeColor(String color) {
        System.out.println(this.color + " changed to " + color);
        this.color = color;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Car.class.getSimpleName() + "[", "]")
                .add("brand='" + brand + "'")
                .add("model='" + model + "'")
                .add("color=" + color)
                .toString();
    }
}
