package edu.school21.Annotation.Model;

import edu.school21.Annotation.Annotations.HtmlForm;
import edu.school21.Annotation.Annotations.HtmlInput;

@HtmlForm(fileName = "user_form.html", action = "/users", method = "post")
public class UserForm {
    @HtmlInput(type = "text", name = "Yuri", placeholder = "Enter First Name")
    private String firstName;
    @HtmlInput(type = "text", name = "Matyushevsky", placeholder = "Enter Last Name")
    private String lastName;
    @HtmlInput(type = "password", name = "code10", placeholder = "Enter Password")
    private String password;
}