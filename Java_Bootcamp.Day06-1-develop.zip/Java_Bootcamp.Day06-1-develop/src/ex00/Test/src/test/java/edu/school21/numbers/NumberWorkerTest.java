package edu.school21.numbers;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.ValueSource;

public class NumberWorkerTest extends Assert {
    private NumberWorker numberWorker;

    @BeforeEach
    void createNumberWorker() {
        numberWorker = new NumberWorker();
    }

    @ParameterizedTest
    @ValueSource(ints = {0, 1, -1, -2, -200})
    public void isPrimeForIncorrectNumbers(final int number) {
        assertThrows(IllegalNumberException.class, () -> numberWorker.isPrime(number));
    }

    @ParameterizedTest
    @ValueSource(ints = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47})
    public void isPrimeForPrime(int number){
        assertTrue(numberWorker.isPrime(number));
    }

    @ParameterizedTest
    @ValueSource(ints = {4, 8, 12, 16, 20, 25, 30, 36, 42, 66, 100, 200, 65536})
    public void isPrimeForNotPrime(int number){
        assertFalse(numberWorker.isPrime(number));
    }

    @ParameterizedTest
    @CsvFileSource(resources = "/data.csv", numLinesToSkip = 0)
    public void digitsum(int number, int sum){
        assertEquals(numberWorker.digitsSum(number), sum);
    }
}
