package edu.school21.numbers;

public class IllegalNumberException extends RuntimeException{
    IllegalNumberException(){
        super("It's number wrong!!!");
    }
}