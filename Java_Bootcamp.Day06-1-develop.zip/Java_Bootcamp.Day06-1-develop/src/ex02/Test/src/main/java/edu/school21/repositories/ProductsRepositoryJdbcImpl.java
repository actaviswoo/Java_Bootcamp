package edu.school21.repositories;

import edu.school21.models.Product;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProductsRepositoryJdbcImpl implements ProductRepostiories {
    private Connection connection;

    public ProductsRepositoryJdbcImpl(Connection connection) throws SQLException {
        this.connection = connection;
    }

    @Override
    public List<Product> findAll() {
        try {
            String query = "SELECT * FROM shop.product";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            List<Product> products = new ArrayList<>();
            while (resultSet.next()) {
                Product product = new Product(resultSet.getLong(1), resultSet.getString(2), resultSet.getLong(3));
                products.add(product);
            }
            return products;
        } catch (SQLException exception) {
            throw new RuntimeException(exception);
        }
    }

    @Override
    public Optional<Product> findById(Long id) {
        try {
            String query = "SELECT * FROM shop.product WHERE id = " + id;
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return Optional.of(new Product(resultSet.getLong(1), resultSet.getString(2), resultSet.getLong(3)));
            }
            return Optional.empty();
        } catch (SQLException exception) {
            throw new RuntimeException(exception);
        }
    }

    @Override
    public void update(Product product) {
        try {
            String query = "UPDATE shop.product SET name = '" + product.getName() + "', price = " + product.getPrice() + " WHERE id = " + product.getId();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.execute();
        } catch (SQLException exception) {
            throw new RuntimeException(exception);
        }
    }

    @Override
    public void save(Product product) {
        try {
            String query = "INSERT INTO shop.product (name, price) VALUES ('" + product.getName() + "', " + product.getPrice() + ")";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.execute();
        } catch (SQLException exception) {
            throw new RuntimeException(exception);
        }
    }

    @Override
    public void delete(Long id) {
        try {
            String query = "DELETE FROM shop.product WHERE id = " + id;
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.execute();
        } catch (SQLException exception) {
            throw new RuntimeException(exception);
        }
    }
}
