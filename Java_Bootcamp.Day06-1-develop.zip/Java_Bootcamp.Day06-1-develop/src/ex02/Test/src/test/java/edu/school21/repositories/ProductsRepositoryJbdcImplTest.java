package edu.school21.repositories;

import edu.school21.models.Product;
import org.junit.jupiter.api.*;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class ProductsRepositoryJbdcImplTest extends Assertions {
    private final List<Product> EXPECTED_FIND_ALL_PRODUCTS = Arrays.asList(
            new Product(0L,"iron branch", 50L),
            new Product(1L, "blink dagger", 2250L),
            new Product(2L, "boots", 500L),
            new Product(3L, "black king bar", 4050L),
            new Product(4L, "divine rapier", 5600L),
            new Product(5L, "tango", 90L),
            new Product(6L, "enchanted mango", 65L)
    );
    private final Optional<Product> EXPECTED_FIND_BY_ID_PRODUCT = Optional.of(new Product(3L, "black king bar", 4050L));
    private final Product EXPECTED_UPDATED_PRODUCT = new Product(0L, "iron branch", 10000L);

    private EmbeddedDatabase embeddedDatabase;
    private ProductsRepositoryJdbcImpl productsRepository;


    @BeforeEach
    public void init() {
        try {
            embeddedDatabase = new EmbeddedDatabaseBuilder()
                    .setType(EmbeddedDatabaseType.HSQL)
                    .addScript("schema.sql")
                    .addScript("data.sql")
                    .build();
            productsRepository = new ProductsRepositoryJdbcImpl(embeddedDatabase.getConnection());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void testFindAll() {
        assertEquals(EXPECTED_FIND_ALL_PRODUCTS, productsRepository.findAll());
    }

    @Test
    public void testFindById() {
        assertEquals(EXPECTED_FIND_BY_ID_PRODUCT, productsRepository.findById(3L));
    }

    @Test
    public void testUpdate() {
        productsRepository.update(new Product(0L, "iron branch", 10000L));
        assertEquals(EXPECTED_UPDATED_PRODUCT, productsRepository.findById(0L).get());
    }

    @Test
    public void testSave() {
        Integer countBefore = productsRepository.findAll().size();
        productsRepository.save(new Product(7L, "clarity", 50L));
        assertEquals(countBefore, productsRepository.findAll().size() - 1);
    }

    @Test
    public void testDelete() {
        Integer countBefore = productsRepository.findAll().size();
        productsRepository.delete(6L);
        assertEquals(countBefore - 1, productsRepository.findAll().size());
    }

}
