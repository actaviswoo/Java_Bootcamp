package edu.school21.services;


import edu.school21.models.User;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.Assertions;
import org.mockito.ArgumentCaptor;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;

import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

import java.sql.SQLException;

import static org.mockito.Mockito.*;

public class UsersServiceImplTest extends Assertions {
    private EmbeddedDatabase embeddedDatabase;
    private UsersServiceImpl usersService;

    UsersServiceImpl mocRepository = mock(UsersServiceImpl.class);

    @BeforeEach
    public void init() throws SQLException {
        this.embeddedDatabase = new EmbeddedDatabaseBuilder().setType(EmbeddedDatabaseType.HSQL)
                .addScript("schema.sql").addScript("data.sql").build();
        try {
            usersService = new UsersServiceImpl(embeddedDatabase.getConnection());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testFindByLogin() {
        User user = new User(0L, "admin", "admin", true);
        mocRepository.findByLogin("admin");
        verify(mocRepository).findByLogin("admin");
        when(mocRepository.findByLogin("admin")).thenReturn(user);
        assertEquals(user, mocRepository.findByLogin("admin"));
    }

    @Test
    public void testUpdate() {
        User user = new User(1L, "code80", "doubleDamage", true);
        ArgumentCaptor<User> valueCaptor = ArgumentCaptor.forClass(User.class);
        doNothing().when(mocRepository).update(valueCaptor.capture());
        mocRepository.update(user);
        assertEquals(user, valueCaptor.getValue());
    }

    @Test
    public void testAuthenticateTrue() {
        mocRepository.authenticate("student", "python_its_izi");
        verify(mocRepository).authenticate("student", "python_its_izi");
    }

    @Test
    public void testAuthenticateFalse() {
        mocRepository.authenticate("student", "python_its_hard");
        verify(mocRepository).authenticate("student", "python_its_hard");
        when(mocRepository.authenticate("student", "python_its_hard")).thenReturn(false);
        assertFalse(mocRepository.authenticate("student", "python_its_hard"));
    }

}