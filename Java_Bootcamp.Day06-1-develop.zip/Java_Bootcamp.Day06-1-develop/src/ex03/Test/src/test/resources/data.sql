INSERT INTO shop.product (name, price) VALUES
    ('iron branch', 50),
    ('blink dagger', 2250),
    ('boots', 500),
    ('black king bar', 4050),
    ('divine rapier', 5600),
    ('tango', 90),
    ('enchanted mango', 65);

INSERT INTO shop.users (login, password, status) VALUES
   ('admin', 'admin', true),
   ('code10', 'n33dSom3Sl33p', true),
   ('student', 'python_its_izi', false);
