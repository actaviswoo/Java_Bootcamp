package edu.school21.services;

import edu.school21.exceptions.EntityNotFoundException;
import edu.school21.models.User;
import edu.school21.repositories.UserRepository;
import edu.school21.exceptions.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;

public class UsersServiceImpl implements UserRepository {
    private Connection connection;
    public UsersServiceImpl(Connection connection) throws SQLException {
        this.connection = connection;
    }

    @Override
    public User findByLogin(String login) {
        try {
            String query = "SELECT * FROM shop.users WHERE login = " + login;
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet userSet = preparedStatement.executeQuery();
            if (userSet.next()) {
                return new User(userSet.getLong(1), userSet.getString(2), userSet.getString(3), userSet.getBoolean(4) );
            } else {
                throw new EntityNotFoundException();
            }
        } catch (SQLException exception) {
            throw new RuntimeException(exception);
        }
    }

    @Override
    public void update(User user) {
        try {
            String query = "UPDATE shop.users SET login = " + user.getLogin() + ", password = " + user.getPassword() + ", authenticated = " + user.isAuthentication() + " WHERE id = " + user.getId();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.executeUpdate();
        } catch (SQLException exception) {
            throw new RuntimeException();
        }
    }

    public boolean authenticate(String login, String password) {
        User user = findByLogin(login);
        if(user.isAuthentication()){
            throw new AlreadyAuthenticatedException();
        }
        user.setAuthentication(Objects.equals(password, user.getPassword()));
        update(user);
        return user.isAuthentication();
    }
}
