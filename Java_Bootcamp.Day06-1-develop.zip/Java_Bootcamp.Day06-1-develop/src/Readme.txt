*for install maven*
https://maven.apache.org/download.cgi

export M2_HOME="/Users/argoniaz/Downloads/apache-maven-3.9.6"
PATH="${M2_HOME}/bin:${PATH}"
export PATH

*move to ex/project*
RUN TEST
mvn clean compile test