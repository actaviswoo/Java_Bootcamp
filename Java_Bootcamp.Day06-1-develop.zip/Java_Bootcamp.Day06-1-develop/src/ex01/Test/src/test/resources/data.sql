INSERT INTO shop.product (name, price) VALUES
    ('iron branch', 50),
    ('blink dagger', 2250),
    ('boots', 500),
    ('black king bar', 4050),
    ('divine rapier', 5600),
    ('tango', 90),
    ('enchanted mango', 65);