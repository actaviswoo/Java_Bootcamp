INSERT INTO service.users(email) VALUES
    ('yeat@gmail.com'),
    ('popsmoke@gmail.com'),
    ('code10@gmail.com')