package edu.school21.Service.Repositories;

import edu.school21.Service.Models.User;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
import java.util.List;
import java.util.Optional;

public class UsersRepositoryJdbcTemplateImpl implements UsersRepository {
    private final JdbcTemplate jdbcTemplate;

    public UsersRepositoryJdbcTemplateImpl(DataSource dataSource){
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public List<User> findAll() {
        String query = "SELECT * FROM service.users";
        return jdbcTemplate.query(query, new UserMapper());
    }

    @Override
    public Optional<User> findById(Long id) {
        String query = "SELECT * FROM service.users WHERE id = " + id;
        List<User> users = jdbcTemplate.query(query, new UserMapper());
        if (!users.isEmpty()) {
            return Optional.ofNullable(users.get(0));
        } else {
            return Optional.empty();
        }
    }

    @Override
    public void save(User entity) {
        String query = "INSERT INTO service.users(email) VALUES (?)";
        jdbcTemplate.update(query, entity.getEmail());
    }

    @Override
    public void update(User entity) {
        String query = "UPDATE service.users SET email = ? WHERE id = ?";
        jdbcTemplate.update(query, entity.getEmail(), entity.getId());
    }

    @Override
    public void delete(Long id) {
        String query = "DELETE FROM service.users WHERE id = ?";
        jdbcTemplate.update(query, id);
    }

    @Override
    public Optional<User> findByEmail(String email) {
        String query = "SELECT * FROM service.users WHERE email = '" + email + "'";
        List<User> users = jdbcTemplate.query(query, new UserMapper());
        if (!users.isEmpty()) {
            return Optional.ofNullable(users.get(0));
        } else {
            return Optional.empty();
        }
    }

}
