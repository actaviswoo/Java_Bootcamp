package edu.school21.Service.Repositories;

import edu.school21.Service.Models.User;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class UserMapper implements RowMapper<User> {
    @Override
    public User mapRow(ResultSet resultSet, int romNum) throws SQLException {
        User user = new User(resultSet.getLong(1), resultSet.getString(2));
        return user;
    }
}
