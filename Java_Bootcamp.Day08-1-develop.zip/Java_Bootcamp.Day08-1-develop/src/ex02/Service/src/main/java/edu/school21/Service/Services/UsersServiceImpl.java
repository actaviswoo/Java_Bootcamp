package edu.school21.Service.Services;

import edu.school21.Service.Models.User;
import edu.school21.Service.Repositories.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component("usersServiceImpl")
public class UsersServiceImpl implements UsersService {

    private UsersRepository repository;
    private UsersRepository repositoryTemplate;
    @Autowired
    public UsersServiceImpl(@Qualifier("usersRepositoryJdbc") UsersRepository repository,
                            @Qualifier("usersRepositoryJdbcTemplate") UsersRepository repositoryTemplate) {
        this.repository = repository;
        this.repositoryTemplate = repositoryTemplate;
    }

    @Override
    public String signUp(String email) {
        UUID password = UUID.randomUUID();
        if(email == null || email.isEmpty()) {
            System.err.println("Error: email not specified");
            return null;
        }
        repositoryTemplate.save(new User(email, password.toString()));
        return password.toString();
    }

    public UsersRepository getRepository() {
        return repository;
    }

    public UsersRepository getRepositoryTemplate() {
        return repositoryTemplate;
    }
}