package edu.school21.Service.Program;

import edu.school21.Service.Config.ApplicationConfig;
import edu.school21.Service.Services.UsersService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Program {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
        UsersService usersService = context.getBean("usersServiceImpl",UsersService.class);
        System.out.println(usersService.signUp("popsmoke@gmail.com"));
    }
}
