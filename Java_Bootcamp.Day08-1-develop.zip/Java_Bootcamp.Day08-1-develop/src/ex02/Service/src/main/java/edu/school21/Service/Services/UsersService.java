package edu.school21.Service.Services;

public interface UsersService {
    String signUp(String email);
}