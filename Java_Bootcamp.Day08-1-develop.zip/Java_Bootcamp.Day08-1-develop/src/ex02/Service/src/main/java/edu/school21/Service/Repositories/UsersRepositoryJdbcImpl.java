package edu.school21.Service.Repositories;

import edu.school21.Service.Models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component("usersRepository")
public class UsersRepositoryJdbcImpl implements UsersRepository {
    private DataSource dataSource;

    @Autowired
    public UsersRepositoryJdbcImpl(@Qualifier("hikariDataSource") DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public List<User> findAll() {
        try(Connection connection = dataSource.getConnection()) {
            String query = "SELECT * FROM service.users";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            List<User> users = new ArrayList<>();
            while (resultSet.next()) {
                users.add(new User(resultSet.getLong(1), resultSet.getString(2)));
            }
            return users;
        } catch (SQLException exception) {
            System.err.println(exception.getMessage());
        }
        return null;
    }

    @Override
    public Optional<User> findById(Long id) {
        try(Connection connection = dataSource.getConnection()) {
            String query = "SELECT * FROM service.users WHERE id = " + id;
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return Optional.of(new User(resultSet.getLong(1), resultSet.getString(2)));
            }
        } catch (SQLException exception) {
            System.err.println(exception.getMessage());
        }
        return Optional.empty();
    }

    @Override
    public void save(User entity) {
        try(Connection connection = dataSource.getConnection()) {
            String query = "INSERT INTO service.users(email, password) VALUES ('" + entity.getEmail() + "', '" + entity.getPassword() + "')";
            PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            ResultSet resultSet = preparedStatement.getGeneratedKeys();
            Long id = resultSet.getLong(1);
            entity.setId(id);
        } catch (SQLException exception) {
            System.err.println(exception.getMessage());
        }
    }

    @Override
    public void update(User entity) {
        try(Connection connection = dataSource.getConnection()) {
            String query = "UPDATE service.users SET email = '"  + entity.getEmail() + "', password = '" + entity.getPassword() + "', WHERE id = " + entity.getId();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.executeUpdate();
        } catch (SQLException exception) {
            System.err.println(exception.getMessage());
        }
    }

    @Override
    public void delete(Long id) {
        try(Connection connection = dataSource.getConnection()) {
            String query = "DELETE FROM service.users WHERE id = " + id;
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.executeUpdate();
        } catch (SQLException exception) {
            System.err.println(exception.getMessage());
        }
    }

    @Override
    public Optional<User> findByEmail(String email) {
        try(Connection connection = dataSource.getConnection()) {
            String query = "SELECT * FROM service.users WHERE email = '" + email + "'";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return Optional.of(new User(resultSet.getLong(1), resultSet.getString(2)));
            }
        } catch (SQLException exception) {
            System.err.println(exception.getMessage());
        }
        return Optional.empty();
    }
}
