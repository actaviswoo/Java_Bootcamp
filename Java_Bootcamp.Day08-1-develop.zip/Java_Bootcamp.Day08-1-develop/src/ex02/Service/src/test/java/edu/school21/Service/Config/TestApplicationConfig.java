package edu.school21.Service.Config;

import edu.school21.Service.Repositories.UsersRepository;
import edu.school21.Service.Repositories.UsersRepositoryJdbcImpl;
import edu.school21.Service.Repositories.UsersRepositoryJdbcTemplateImpl;
import edu.school21.Service.Services.UsersService;
import edu.school21.Service.Services.UsersServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

import javax.sql.DataSource;

@Configuration
public class TestApplicationConfig {
    @Bean
    public DataSource dataSource() {
        DataSource dataSource = new EmbeddedDatabaseBuilder().
                setType(EmbeddedDatabaseType.HSQL).
                addScript("schema.sql").
                build();
        return dataSource;
    }
    @Bean
    public UsersRepository usersRepositoryJdbcTemplate() {
        return new UsersRepositoryJdbcTemplateImpl(dataSource());
    }
    @Bean
    public UsersRepository usersRepositoryJdbc() {
        return new UsersRepositoryJdbcImpl(dataSource());
    }
    @Bean
    public UsersService usersServiceImpl() {
        return new UsersServiceImpl(usersRepositoryJdbc(), usersRepositoryJdbcTemplate());
    }
    @Bean
    public UsersService usersServiceTemplate() {
        return new UsersServiceImpl(usersRepositoryJdbc(), usersRepositoryJdbcTemplate());
    }
}