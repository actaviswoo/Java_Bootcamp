package edu.school21.Spring.Printer;

import edu.school21.Spring.Renderer.Renderer;

public class PrinterWithPrefixImpl implements Printer {
    private Renderer renderer;
    private String prefix = "<default prefix>";

    public PrinterWithPrefixImpl(Renderer renderer) {
        this.renderer = renderer;
    }
    @Override
    public void print(String message) {
        renderer.render(prefix + " " + message);
    }
    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }
}