package edu.school21.Spring.Program;

import edu.school21.Spring.Printer.Printer;
import edu.school21.Spring.Printer.PrinterWithDateTimeImpl;
import edu.school21.Spring.Printer.PrinterWithPrefixImpl;
import edu.school21.Spring.Processor.PreProcessor;
import edu.school21.Spring.Processor.PreProcessorToLowerImpl;
import edu.school21.Spring.Processor.PreProcessorToUpperImpl;
import edu.school21.Spring.Renderer.Renderer;
import edu.school21.Spring.Renderer.RendererErrImpl;
import edu.school21.Spring.Renderer.RendererStandardImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Program {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
        PrinterWithDateTimeImpl printerWithDateTime = context.getBean("printerWithDateTimeErrToUpper", PrinterWithDateTimeImpl.class);
        printerWithDateTime.print("zaza");
        PrinterWithPrefixImpl printerWithPrefix = context.getBean("printerWithPrefixOutToUpper", PrinterWithPrefixImpl.class);
        printerWithPrefix.print("code10");
        printerWithPrefix = context.getBean("printerWithPrefixOutToLower", PrinterWithPrefixImpl.class);
        printerWithPrefix.setPrefix("code80");
        printerWithPrefix.print("scalevillain");
    }
}
