package edu.school21.Spring.Renderer;

public interface Renderer {
    void render(String text);
}
