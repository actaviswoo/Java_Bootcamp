package edu.school21.Spring.Processor;

public interface PreProcessor {
    String process(String text);
}
