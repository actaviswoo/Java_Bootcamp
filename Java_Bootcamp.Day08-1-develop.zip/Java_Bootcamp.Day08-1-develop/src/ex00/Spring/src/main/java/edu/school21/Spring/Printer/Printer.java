package edu.school21.Spring.Printer;

public interface Printer {
    void print(String text);
}
