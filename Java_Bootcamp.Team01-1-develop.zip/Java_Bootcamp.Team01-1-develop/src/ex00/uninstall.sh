#!bin/bash

rm -rf Game TanksClient/target TanksServer/target TanksClient/dependency-reduced-pom.xml