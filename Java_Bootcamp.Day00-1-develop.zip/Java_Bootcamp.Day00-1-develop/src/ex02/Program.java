import java.util.Scanner;
class Main {
    public static int sumDigit(int num) {
        int res = 0;
        while (num > 0) {
            res = res + num % 10;
            num = num / 10;
        }
        return res;
    }

    public static int isPrime(int num) {
        int i = 2;
        for (; i * i <= num; i++) {
            if (num % i == 0) {
                return 0;
            } 
        }
        return 1;
    } 
    public static void main(String[] args) {
        int count = 0;
        int num = 0;
        Scanner s = new Scanner(System.in);
        while (num != 42) {
            if (s.hasNextInt()) {
                num = s.nextInt();
                if (num <= 1) {
                    System.err.println("Illegal argument");
                    s.close();
                    System.exit(-1);
                }
                count += isPrime(sumDigit(num));
            } else {
                System.err.println("Illegal argument");
                s.close();
                System.exit(-1);
            }
        }
        s.close();
        System.out.println("Count of coffee-request - " + count);
    }
}