import java.util.Scanner;
class Main {
    public static void except(Scanner s) {
        System.err.println("IllegalArgument");
        s.close();
        System.exit(-1);
    }
    public static long input() {
        Scanner s = new Scanner(System.in);
        String week = new String();
        int weekCounter = 0;
        long result = 0;
        while (!(week = s.nextLine()).equals("42") && ((++weekCounter) <= 18)) {
            if (!week.equals("Week " + weekCounter)) except(s);                  
            if (!s.hasNextInt()) except(s);                 
            int num1 = s.nextInt();
            if (num1 < 1 || num1  > 9) except(s);                  
            for (int i = 0; i < 4; i++) {
                if (!s.hasNextInt()) except(s);
                int num2 = s.nextInt();
                if (num2 < 1 || num2  > 9) except(s);
                if (num2 < num1) {
                    num1 = num2;
                }
            }
            result += num1;
            result *= 10;
            s.nextLine();
        }
        return result;
    }
    public static void printStat(long stat) {
        int count = 1;
        long reverse = 0, remainder;
        while (stat != 0) {
            remainder = stat % 10;
            reverse = reverse * 10 + remainder;
            stat /= 10;
        }
        while (reverse != 0) {
            System.out.print("Week " + count + " ");
            for (int i = 0; i < (reverse % 10); i++) {
                System.out.print("=");
            }
            System.out.print(">\n");
            reverse /= 10;
            count++;
        }
    }
    public static void main(String[] args) {
        long stat = (input() / 10);
        printStat(stat);
    }
}
