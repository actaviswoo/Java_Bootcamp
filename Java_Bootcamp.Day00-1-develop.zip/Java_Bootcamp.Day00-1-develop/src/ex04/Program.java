import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        //char[] line = {'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D', 'W', 'E', 'W', 'W', 'K', 'F', 'K', 'K', 'D', 'K', 'K', 'D', 'S', 'K', 'A', 'K', 'L', 'S', 'L', 'D', 'K', 'S', 'K', 'A', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'R', 'T', 'R', 'T', 'E', 'T', 'W', 'T', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'O', 'O', 'O', 'O', 'O', 'O', 'O', '4', '2'};
        char[] line = new Scanner(System.in).nextLine().toCharArray();
        int[] uniqueArray = fillUniqueArray(line);
        char[] topCharArray = fillTopCharArray(uniqueArray);
        int[] topIntArray = fillTopIntArray(uniqueArray, topCharArray);
        printHstogram(topIntArray, uniqueArray, topCharArray);
    }
    
    public static int[] fillUniqueArray(char[] line) {
        int[] uniqueArray = new int[65535];
        for (char c : line) {
            uniqueArray[c]++;
        }
        return uniqueArray;
    }

    public static char[] fillTopCharArray(int[] uniqueArray) {
        char[] topCharArray = new char[10];
        for (int i = 0; i < 65535; i++) {
            int itCount = uniqueArray[i];
            if (itCount > 0) {
                for (int j = 0; j < 10; j++) {
                    if(uniqueArray[topCharArray[j]] < itCount) {
                        topCharArray = insertTopCharArray(topCharArray, (char) i, j); 
                        break;
                    }
                }
            }
        }
        return topCharArray;
    }

    public static char[] insertTopCharArray(char[] topCharArray, char c, int j) {
        char[] res = new char[10];
        for (int i = 0; i < j; i++) {
            res[i] = topCharArray[i];
        }
        res[j] = c;
        for (int i = j + 1; i < 10; i++) {
            res[i] = topCharArray[i - 1];
        }
        return res;
    }

    public static void printHstogram(int[] topIntArray, int[] uniqueArray, char[] topCharArray) {
        int max = uniqueArray[topCharArray[0]];
        int maxH = max <= 10 ? max : 10;
        System.out.println();
        for (int i = 0; i < 2 + maxH; i++) {
            for (int j = 0; j < 10; j++) {
                if (topCharArray[j] != 0) {
                    if (i + topIntArray[j] == maxH) {
                        System.out.printf("%3d", uniqueArray[topCharArray[j]]);
                    } else if (i == 2 + maxH - 1) {
                        System.out.printf("%3c", topCharArray[j]);
                    } else if (i + topIntArray[j] >= maxH) {
                        System.out.printf("%3c", '#');
                    }
                    if (j != 10 - 1 && topCharArray[j + 1] != 0 && i + topIntArray[j + 1] >= maxH) {
                        System.out.printf("%c", ' ');
                    }
                }
            }
            System.out.println();
        }
    }

    public static int[] fillTopIntArray(int[] uniqueArray, char[] topCharArray) {
        int[] topIntArray = new int[10];
        for (int i = 0; i < 10; i++) {
            if (uniqueArray[topCharArray[0]] <= 10) {
                topIntArray[i] = uniqueArray[topCharArray[i]];
            } else {
                topIntArray[i] = uniqueArray[topCharArray[i]] * 10 / uniqueArray[topCharArray[0]];
            }
        }
        return topIntArray;
    }
}