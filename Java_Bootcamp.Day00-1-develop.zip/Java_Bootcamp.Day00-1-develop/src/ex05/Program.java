import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String[] names = new String[10];
        String[][] timeDay = new String[50][2];
        String[][] nameTimeDateStatus = new String[500][4];
        int itNames = namesInput(names, s);
        int itTimeDay = timeDayInput(timeDay, s);
        int itNameTimeDateStatus = nameTimeDateStatusInput(names, timeDay, nameTimeDateStatus, s);
        printTable(names, itNames, timeDay, itTimeDay, nameTimeDateStatus, itNameTimeDateStatus);    
    }

    public static void printTable(String[] names, int itNames, String[][] timeDay, int itTimeDay,  String[][] nameTimeDateStatus, int itNameTimeDateStatus) {
        System.out.print("          |");
        int[] itCols = new int[1];
        itCols[0] = 0;
        String[][] timeDate = new String[50][2];
        for (int i = 1; i < 31; i++) {
            for (int j = 0; j < 50; j++) {
                if (timeDay[j][1] != null && timeDay[j][1].equals("MO") && (i % 7 == 0)) {
                    if (!printCols(timeDay, j, i, itCols, "MO", timeDate)) break;
                    i++;
                } else if (timeDay[j][1] != null && timeDay[j][1].equals("TU") && (i % 7 == 1)) {
                    if (!printCols(timeDay, j, i, itCols, "TU", timeDate)) break;
                    i++;
                } else if (timeDay[j][1] != null && timeDay[j][1].equals("WE") && (i % 7 == 2)) {
                    if (!printCols(timeDay, j, i, itCols, "WE", timeDate)) break;
                    i++;
                } else if (timeDay[j][1] != null && timeDay[j][1].equals("TH") && (i % 7 == 3)) {
                    if (!printCols(timeDay, j, i, itCols, "TH", timeDate)) break;
                    i++;
                } else if (timeDay[j][1] != null && timeDay[j][1].equals("FR") && (i % 7 == 4)) {
                    if (!printCols(timeDay, j, i, itCols, "FR", timeDate)) break;
                    i++;
                } else if (timeDay[j][1] != null && timeDay[j][1].equals("SA") && (i % 7 == 5)) {
                    if (!printCols(timeDay, j, i, itCols, "SA", timeDate)) break;
                    i++;
                } else if (timeDay[j][1] != null && timeDay[j][1].equals("SU") && (i % 7 == 6)) {
                    if (!printCols(timeDay, j, i, itCols, "SU", timeDate)) break;
                    i++;
                }
            }
        }
        inputInTable(names, itNames, nameTimeDateStatus, itNameTimeDateStatus, timeDate, itCols);
    }

    public static boolean printCols(String[][] timeDay, int j, int i, int[] itCols, String d, String[][] timeDate) {
        for (int k = 0; k < 50; k++) {
            if (timeDay[k][1] != null && timeDay[k][1].equals(d)) {
                if (itCols[0] == 50) return true;
                System.out.printf("%1s:00 %s %2d|", timeDay[k][0], timeDay[j][1], i);
                timeDate[itCols[0]][0] = timeDay[k][0];
                timeDate[itCols[0]][1] = (i + "");
                itCols[0]++;
            }
        }
        return false;
    }

    public static void inputInTable(String[] names, int itNames, String[][] nameTimeDateStatus, int itNameTimeDateStatus, String[][] timeDate, int[] itCols) {
        for (int i = 0; i < itNames; i++) {
            if (names[i] != null) System.out.printf("\n%10s|", names[i]);
            int[] inputs = new int[itCols[0]];
            int itInputs = 0;
            for (int j = 0; j < itNameTimeDateStatus; j++) {
                if (names[i].equals(nameTimeDateStatus[j][0])) {
                    inputs[itInputs] = j;
                    itInputs++;
                }
            }
            for (int j = 0; j < itCols[0]; j++) {
                boolean flag = true;
                for(int k = 0; k < itInputs; k++) {
                    if (timeDate[j][1].equals(nameTimeDateStatus[inputs[k]][2]) &&
                    timeDate[j][0].equals(nameTimeDateStatus[inputs[k]][1]) && 
                    nameTimeDateStatus[inputs[k]][3].equals("NOT_HERE")) {
                        System.out.printf("        %d|", -1);
                        flag = false;
                    } else if (timeDate[j][1].equals(nameTimeDateStatus[inputs[k]][2]) &&
                    timeDate[j][0].equals(nameTimeDateStatus[inputs[k]][1]) && 
                    nameTimeDateStatus[inputs[k]][3].equals("HERE")) {
                        System.out.printf("         %d|", 1);  
                        flag = false;
                    }
                }
                if (flag == true) System.out.printf("          |"); 
            }
        }
    }   
    
    public static int namesInput(String[] names, Scanner s) {
        int itNames = 0;
        String line = new String();
        while (!(line = s.nextLine()).equals(".")) {
            if (line.length() > 10) {               
                System.err.println("Illegal Argument");
                System.exit(-1);
            }
            if (line != "" && !existName(names, line)) {
                names[itNames] = line;
                itNames++;
            }
            if (itNames == 10) {
                System.out.println(".");
                break;
            }
        }
        return itNames;
    }

    public static int timeDayInput(String[][] timeDay, Scanner s) {
        int itTimeDay = 0;
        String time = new String();
        String day = new String();
        while(!(time = s.next()).equals(".")) {
            if (!checkTime(time)) {
                System.err.println("Illegal Argument");
                System.exit(-1);
            }
            day = s.next();
            if (day.equals(".")) {
                System.out.println(".");
                return itTimeDay;
            } else if (!checkDay(day)) {
                System.err.println("Illegal Argument");
                System.exit(-1);
            }
            if (!existTimeDay(timeDay, time, day)) {
                timeDay[itTimeDay][0] = time;
                timeDay[itTimeDay][1] = day;
                itTimeDay++;
            }
            if (itTimeDay == 10) {
                System.out.println(".");
                break;
            }
        }
        return itTimeDay;
    }

    public static int nameTimeDateStatusInput(String[] names, String[][] timeDay,
        String[][] nameTimeDateStatus, Scanner s) {
        int itNameTimeDayStatus = 0;
        String name = new String();
        String time = new String();
        String date = new String();
        String status = new String();
        while(!(name = s.next()).equals(".")) {
            if (existName(names, name) && !(time = s.next()).equals(".")
                && checkTime(time) && !(date = s.next()).equals(".") &&
                checkDate(date) && existTimeDayDate(timeDay, time, date) && 
                !(status = s.next()).equals(".") && checkStatus(status)) {
                if (!existNameTimeDateStatus(nameTimeDateStatus, name, time, date, status)) {
                    nameTimeDateStatus[itNameTimeDayStatus][0] = name;
                    nameTimeDateStatus[itNameTimeDayStatus][1] = time;
                    nameTimeDateStatus[itNameTimeDayStatus][2] = date;
                    nameTimeDateStatus[itNameTimeDayStatus][3] = status;
                    System.out.println("input");
                    itNameTimeDayStatus++;
                }
            } else if (time.equals(".") || date.equals(".") || status.equals(".")) {
                System.out.println(".");
                return itNameTimeDayStatus;
            }
        }
        return itNameTimeDayStatus;
    }

    public static boolean existTimeDay(String[][] timeDay,  String time, String day) {
        for (int i = 0; i < 50; i++) {
            if (timeDay[i][0] == null || timeDay[i][1] == null) break;
            if (time.equals(timeDay[i][0]) && day.equals(timeDay[i][1])) {
                return true;
            }
        }
        return false;
    }

    public static boolean existName(String[] names, String name) {
        for (int i = 0; i < 10; i++) {
            if (name.equals(names[i])) {
                return true;
            }
        }
        return false;
    }

    public static boolean checkTime(String time) {
        return time.equals("1") || time.equals("2") || time.equals("3") 
            || time.equals("4") || time.equals("5") || time.equals("6");
    }

    public static boolean checkDay(String day) {
        return day.equals("MO") || day.equals("TU") || day.equals("WE")
            || day.equals("TH") || day.equals("FR") || day.equals("SA")
            || day.equals("SU");
    }

    public static boolean checkDate(String date) {
        String[] validDates = {"1", "2", "3", "4", "5", "6", "7", 
                               "8", "9", "10", "11", "12", "13", "14",
                               "15", "16", "17", "18", "19", "20", "21",
                               "22", "23", "24", "25", "26", "27", "28",
                               "29", "30"};               
        for (String validDate : validDates) {
            if (validDate.equals(date)) {
                return true;
            }
        }
        return false;
    }   

    public static boolean checkStatus(String status) {
        return status.equals("NOT_HERE") || status.equals("HERE");
    }

    public static boolean existTimeDayDate(String[][] timeDay, String time, String date) {
        String[][] validDayDate = {
                      {"TU",  "1"}, {"WE",  "2"}, {"TH",  "3"}, {"FR",  "4"}, {"SA", "5"}, {"SU",  "6"}, 
        {"MO",  "7"}, {"TU",  "8"}, {"WE",  "9"}, {"TH", "10"}, {"FR", "11"}, {"SA","12"}, {"SU", "13"},
        {"MO", "14"}, {"TU", "15"}, {"WE", "16"}, {"TH", "17"}, {"FR", "18"}, {"SA","19"}, {"SU", "20"},
        {"MO", "21"}, {"TU", "22"}, {"WE", "23"}, {"TH", "24"}, {"FR", "25"}, {"SA","26"}, {"SU", "27"},
        {"MO", "28"}, {"TU", "29"}, {"WE", "30"}};
        for (int j = 0; j < 30; j++) {              
            for (int i = 0; i < 50; i++) {
                if (time.equals(timeDay[i][0]) && (validDayDate[j][0].equals(timeDay[i][1]) 
                && validDayDate[j][1].equals(date))) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean existNameTimeDateStatus(String[][] nameTimeDateStatus, String name, String time, String date, String status) {
        for (int i = 0; i < 500; i++) {              
            if (nameTimeDateStatus[i][0] == null || nameTimeDateStatus[i][1] == null
            || nameTimeDateStatus[i][2] == null || nameTimeDateStatus[i][3] == null) {
                break;
            }
            if (name.equals(nameTimeDateStatus[i][0]) && time.equals(nameTimeDateStatus[i][1])
            && date.equals(nameTimeDateStatus[i][2]) && status.equals(nameTimeDateStatus[i][3])) {
                return true;
            }
        }
        return false;
    }
}