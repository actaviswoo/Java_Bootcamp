
import java.util.Scanner;
import java.util.UUID;

import org.omg.IOP.TransactionService;

public class Menu {
    private TransactionsService TransactionsService;
    private Scanner Scanner;

    public Menu() {
        TransactionsService = new TransactionsService();
        Scanner = new Scanner(System.in);
    }

    public void Start(boolean dev) {
        printMenu(dev);
        actionMenu(dev);
    }    
    private void printMenu(boolean dev) {
        System.out.println("1. Add a user");
        System.out.println("2. View user balances");
        System.out.println("3. Perform a transfer");
        System.out.println("4. View all transactions for a specific user");
        if(dev) {
            System.out.println("5. DEV – remove a transfer by ID");
            System.out.println("6. DEV – check transfer validity");
            System.out.println("7. Finish execution");
        } else {
            System.out.println("5. Finish execution");
        }
        System.out.print("-> ");
    }
    
    private void actionMenu(boolean dev) {
        if (dev) {
            actionRoot();
        } else {
            actionDefault();
        }
    }

    private void actionRoot() {
        switch (Scanner.next()) {
            case "1":
                addUser(true);
                break;
            case "2":
                viewBalance(true);
                break;
            case "3":
                performTransfer(true);
                break;
            case "4":
                viewTransactions(true);
                break;
            case "5":
                removeTransferById(true);
                break;
            case "6":
                checkTransfer(true);
                break;
            case "7":
                System.exit(0);
                break;
            default:
                System.err.println("Try again");
                System.out.println("---------------------------------------------------------");
                Start(true);
        }
    }

    private void actionDefault() {
        switch (Scanner.next())  {
            case "1":
                addUser(false);
                break;
            case "2":
                viewBalance(false);
                break;
            case "3":
                performTransfer(false);
                break;
            case "4":
                viewTransactions(false);
                break;
            case "5":
                System.exit(0);
                break;
            default:
                System.err.println("Try again");
                System.out.println("---------------------------------------------------------");
                Start(false);
        }
    }

    private void addUser(boolean dev) {
        try {
            System.out.println("Enter a user name and a balance (ex. \"name 100\")");
            String name = Scanner.next();
            Integer balance = Scanner.nextInt();
            User user = new User(name, balance);
            TransactionsService.addUser(user);
            System.out.printf("User with id = %d is added\n", user.getIdentifier());
            Start(dev);
        } catch (RuntimeException rex) {
            System.out.println(rex);
            addUser(dev);
        }
    }

    private void viewBalance(boolean dev) {
        try {
            System.out.println("Enter a user ID (ex. \"0\")");
            Integer id = Scanner.nextInt();
            User user = TransactionsService.getUsersList().getUserById(id);
            System.out.printf("%s - %d\n", user.getName(), user.getBalance());
            System.out.println("---------------------------------------------------------");
            Start(dev);
        } catch (RuntimeException rex) {
            System.out.println(rex);
            Start(dev);
        }
    }

    private void performTransfer(boolean dev) {
        try {
            System.out.println("Enter a recipient ID, a sender ID, and a transfer amount (ex. \"0 1 1000\")");
            Integer sender = Scanner.nextInt();
            Integer recipient = Scanner.nextInt();
            Integer transferAmount = Scanner.nextInt();
            TransactionsService.doTransaction(recipient, sender, transferAmount);
            System.out.println("The transfer is completed");
            System.out.println("---------------------------------------------------------");
            Start(dev);
        } catch (RuntimeException rex) {
            System.out.println(rex);
            Start(dev);
        }
    }

    private void viewTransactions(boolean dev) {
        try {
            System.out.println("Enter a user ID (ex. \"0\")");
            Integer id = Scanner.nextInt();
            User user = TransactionsService.getUsersList().getUserById(id);
            for (Transaction transaction : TransactionsService.getUsersList().getUserById(id).getTransactionsLinkedList().toArray()) {
                System.out.printf("To %s(id = %d) %s%d with id = %s\n",
                user.getName(), user.getIdentifier(), transaction.getTransferCategory() == Transaction.Category.CREDIT ? "-" : "+",transaction.getTransferAmount(), transaction.getIdentifier());
            }
            System.out.println("---------------------------------------------------------");
            Start(dev);
        } catch (RuntimeException rex) {
            System.out.println(rex);
            Start(dev);
        }
    }

    private void removeTransferById(boolean dev) {
        try {
            System.out.println("Enter a transfer ID and a user ID (ex. \"7534d9b...ed5 0\")");
            String transactionIdentifier = Scanner.next();
            UUID transactionId = UUID.fromString(transactionIdentifier);
            Integer userIdentifier = Scanner.nextInt();
            User user = TransactionsService.getUsersList().getUserById(userIdentifier);
            int transferAmount = 0;
            boolean flag = false;
            Transaction.Category category = Transaction.Category.CREDIT;
            for (Transaction transaction : TransactionsService.getUsersList().getUserById(userIdentifier).getTransactionsLinkedList().toArray()) {
                if (transaction.getIdentifier().equals(transactionId)) {
                    transferAmount = transaction.getTransferAmount();
                    category = transaction.getTransferCategory();
                    flag = true;
                }   
            }
            TransactionsService.removeTransactionById(transactionId, userIdentifier);
            if (flag == true) System.out.printf("Transfer to %s(id = %d) %s%d removed\n",
                user.getName(), user.getIdentifier(), category == Transaction.Category.CREDIT ? "-" : "+",transferAmount);
            System.out.println("---------------------------------------------------------");
            Start(dev);
        } catch (RuntimeException rex) {
            System.out.println(rex);
            Start(dev);
        }
    }

    private void checkTransfer(boolean dev) {
        try {
            for (Transaction transaction : TransactionsService.getUnpairedTransactions()) {
                System.out.printf("%s(id = %d) has an unacknowledged transfer id = " + "%s " + "from %s(id = %d) for %s%d\n",
                        transaction.getRecipient().getName(), transaction.getRecipient().getIdentifier(), transaction.getIdentifier(), transaction.getSender().getName(),
                        transaction.getSender().getIdentifier(), transaction.getTransferCategory() == Transaction.Category.CREDIT ? "-" : "+", transaction.getTransferAmount());
                System.out.println("---------------------------------------------------------");
                Start(dev);
            }
        } catch (RuntimeException rex) {
            System.out.println(rex);
            Start(dev);
        }
    }

}
