public class TransactionNotFoundException extends RuntimeException {
    public TransactionNotFoundException() {
        super("not found");
    }
}