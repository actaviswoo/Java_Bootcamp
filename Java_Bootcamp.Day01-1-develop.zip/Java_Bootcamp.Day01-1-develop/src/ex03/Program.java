public class Program {
    public static void main(String[] args) {
        User a = new User("a", 1000);
        User b = new User("b", 1000);
        User c = new User("c", 1000);
        User d = new User("d", 1000);
        Transaction tr1 = new Transaction(a, b, 400);
        Transaction tr2 = new Transaction(b, c, 300);
        Transaction tr3 = new Transaction(c, d, -200);
        Transaction tr4 = new Transaction(d, a, -100);
        TransactionsList transactionsList = new TransactionsLinkedList();
        transactionsList.addTransaction(tr1);
        transactionsList.addTransaction(tr2);
        transactionsList.addTransaction(tr3);
        transactionsList.addTransaction(tr4);
        transactionsList.printConsole();
        System.out.println();

        transactionsList.removeTransaction(tr3.getIdentifier());
        Transaction[] transactionsArray = transactionsList.toArray();
        for (int i = 0; i < transactionsList.getSize(); i++) {
            System.out.print(transactionsArray[i].getTransferCategory() + " ");
            transactionsArray[i].printConsole();
        }
    }
}