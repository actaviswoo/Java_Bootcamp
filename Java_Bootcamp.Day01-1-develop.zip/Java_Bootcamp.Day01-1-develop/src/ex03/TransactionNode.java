public class TransactionNode {
    private Transaction Transaction;
    private TransactionNode Next = null;
    private TransactionNode Prev = null;

    public TransactionNode(Transaction transaction) {
        Transaction = transaction;
    }

    public TransactionNode(TransactionNode prev, Transaction transaction, TransactionNode next) {
        Transaction = transaction;
        Next = next;
        Prev = prev;
    }

    public Transaction getTransaction() {
        return Transaction;
    }

    public TransactionNode getNext() {
        return Next;
    }

    public TransactionNode getPrev() {
        return Prev;
    }

    public void setNext(TransactionNode next) {
        Next = next;
    }

    public void setPrev(TransactionNode prev) {
        Prev = prev;
    }
}