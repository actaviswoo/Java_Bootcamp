public class Program {
    public static void main(String[] args) {
        User user1 = new User(1, "user1", 1000);
        User user2 = new User(2, "user2", 1000);
        user1.setBalance(-1600);
        user2.setBalance(1500);
        System.out.println(user1);
        System.out.println(user2);
        Transaction trans1 = new Transaction(user1, user2, -1500);
        trans1.printConsole();
        //System.out.println(trans1);
    }
}