public class UserInitException extends RuntimeException {
    public UserInitException() {
        super("can't init user");
    }
}
