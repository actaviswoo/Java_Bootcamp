public class TransactionInitException extends RuntimeException {
    public TransactionInitException() {
        super("can't init transaction");
    }
}
