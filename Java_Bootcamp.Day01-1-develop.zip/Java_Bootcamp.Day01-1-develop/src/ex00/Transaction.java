import java.util.UUID;

public class Transaction {
    private UUID Identifier;
    private User Recipient;
    private User Sender;
    private Integer TransferAmount;
    private Category TransferCategory;
    enum Category {
        DEBIT, CREDIT
    }
    public Transaction(User recipient, User sender, Integer transferAmount) {
        if ((transferAmount > 0 && sender.getBalance() < transferAmount) || 
            (transferAmount < 0 && recipient.getBalance() < -transferAmount) ||
            recipient.getIdentifier() == sender.getIdentifier()) {
            throw new TransactionInitException();
        } else {
            Identifier = UUID.randomUUID();
            Recipient = recipient;
            Sender = sender;
            TransferAmount = transferAmount;
            TransferCategory = transferAmount < 0 ? Category.CREDIT : Category.DEBIT;
            sender.setBalance(sender.getBalance() - transferAmount);
            recipient.setBalance(recipient.getBalance() + transferAmount);
        }
    }

    public UUID getIdentifier() {
        return Identifier;
    }
    public User getRecipient() {
        return Recipient;
    }
    public User getSender() {
        return Sender;
    }
    public Integer getTransferAmount() {
        return TransferAmount;
    }
    public Category getTransferCategory() {
        return TransferCategory;
    }
    public void setIdentifier(UUID identifier) {
        Identifier = identifier;
    }
    public void setRecipient(User recipient) {
        Recipient =  recipient;
    }
    public void setSender(User sender) {
        Sender = sender;
    }
    public void setTransferAmount(Integer transferAmount) {
        TransferAmount = transferAmount;
    }
    public void setTransferCategory(Category transferCategory) {
        TransferCategory = transferCategory;
    }
    
    public void printConsole() {
        if (TransferCategory == Category.DEBIT) {
            System.out.println(Sender.getName() + " -> " + Recipient.getName() + ", -" + TransferAmount + ", OUTCOME, transaction " + Identifier);
            System.out.println(Recipient.getName() + " -> " + Sender.getName() + ", +" + TransferAmount + ", INCOME, transaction " + Identifier);
        } else {
            System.out.println(Recipient.getName() + " -> " + Sender.getName() + ", -" + (-TransferAmount) + ", OUTCOME, transaction " + Identifier);
            System.out.println(Sender.getName() + " -> " + Recipient.getName() + ", +" + (-TransferAmount) + ", INCOME, transaction " + Identifier);    
        }
    }
}