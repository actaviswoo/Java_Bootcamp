public class User {
    private Integer Identifier;
    private String Name;
    private Integer Balance;

    public Integer getIdentifier() {
        return Identifier;
    }
    public String getName() {
        return Name;
    }
    public Integer getBalance() {
        return Balance;
    }
    public void setIdentifier(Integer indentifier) {
        Identifier = indentifier;
    }
    public void setName(String name) {
        Name = name;
    }
    public void setBalance(Integer balance) {
        Balance = balance;
    }

    public User(Integer identifier, String name, Integer balance) {
        if (balance < 0) {
            throw new UserInitException();
        } else {
            Identifier = identifier;
            Name = name;
            Balance = balance;
        }
    }

    @Override
    public String toString() {
        return "[name:" + Name + "][id:" + Identifier + "][" + "[balance:" + Balance + "]";
    }
}
