public class UserNotFoundException extends RuntimeException {
    public UserNotFoundException() {
        super("not found");
    }
}