public class Program {
    public static void main(String[] args) {
        User user1 = new User("user1", 2600);
        User user2 = new User("user2", 1000);
        User user3 = new User("user3", 100);

        System.out.println(user1);
        System.out.println(user2);
        System.out.println(user3);

        UsersArrayList u1 = new UsersArrayList();
        u1.addUser(user1);
        u1.addUser(user3);
        u1.addUser(user2);
        System.out.println(u1.getUserById(0));
        System.out.println(u1.getUserByIndex(2));
        System.out.println(u1.getUserCount());

        // System.out.println(u1.getUserById(100));
        // System.out.println(u1.getUserByIndex(100));
    }
}