public class UserIdsGenerator {
    private static Integer Identifier = 0;
    private static UserIdsGenerator Instance;

    public static UserIdsGenerator getInstance() {
        if (Instance == null) {
            Instance = new UserIdsGenerator();
        }
        return Instance;
    }

    public int generateId(){
        return Identifier++;
    }
}
