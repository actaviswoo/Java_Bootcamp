import java.util.UUID;

public interface TransactionsList {
    void addTransaction(Transaction transaction);
    void removeTransaction(UUID identifier);
    Transaction[] toArray();
    Integer getSize();
    void printConsole();
    Transaction getTransactionById(UUID identifier);
}
