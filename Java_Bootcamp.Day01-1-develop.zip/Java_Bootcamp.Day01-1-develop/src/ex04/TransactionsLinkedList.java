import java.util.UUID;

public class TransactionsLinkedList implements TransactionsList {
    private TransactionNode Head;
    private TransactionNode Tail;
    private Integer Size = 0;

    @Override
    public void addTransaction(Transaction transaction) {
        TransactionNode current = new TransactionNode(transaction);
        if (Head == null) {
            Head = current;
            Tail = current;
        } else {
            Tail.setNext(current);
            current.setPrev(Tail);
            Tail = current;
        }
        Size++;
    }

    @Override
    public void removeTransaction(UUID identifier) {
        if (identifier == null) {
            throw new TransactionNotFoundException();
        }
        TransactionNode current = Head;
        while(current != null) {
            if (current.getTransaction().getIdentifier().equals(identifier)) {
                if (current.getPrev() != null && current.getNext() != null) {
                    current.getPrev().setNext(current.getNext());
                    current.getNext().setPrev(current.getPrev());
                } else if (current.getPrev() == null) {
                    Head = current.getNext();
                    if (current.getNext() != null) {
                        current.getNext().setPrev(null);
                    }
                } else {
                    Tail = current.getPrev();
                    if (current.getPrev() != null) {
                        current.getPrev().setNext(null);
                    }
                }
                Size--;
                return;
            }
            current = current.getNext();
        }
    }

    public Integer getSize() {
        return Size;
    }

    @Override
    public Transaction[] toArray() {
        Transaction[] transactions = new Transaction[Size];
        TransactionNode current = Head;
        if (Size > 0) {
            for (int i = 0; i < Size; i++) {
                transactions[i] = current.getTransaction();
                current = current.getNext();
            }
        }
        return transactions;
    }

    @Override
    public Transaction getTransactionById(UUID identifier) {
        if (identifier == null) {
            throw new TransactionNotFoundException();
        }
        TransactionNode current = Head;
        while(current != null) {
            if (current.getTransaction().getIdentifier().equals(identifier)) {
                return current.getTransaction();
            }
            current = current.getNext();
        }
        throw new TransactionNotFoundException();
    }

    @Override
    public void printConsole() {
        Transaction[] transactionsArray = toArray();
        for (int i = 0; i < Size; i++) {
            transactionsArray[i].printConsole();
        }
    }
}
