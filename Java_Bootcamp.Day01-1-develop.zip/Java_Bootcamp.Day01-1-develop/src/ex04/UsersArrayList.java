public class UsersArrayList implements UsersList {
    private User[] Users = new User[10];
    private int UserCount = 0;

    @Override
    public void addUser(User user) {
        if (UserCount >= Users.length) {
            User[] temp = new User[Users.length * 2];
            for (int i = 0; i < Users.length; i++) {
                temp[i] = Users[i];
            }
            Users = temp;
        }
        Users[UserCount++] = user;
    }

    @Override
    public User getUserById(Integer id) {
        for (int i = 0; i < UserCount; i++) {
            if (Users[i].getIdentifier() == id) {
                return Users[i];
            }
        }
        throw new UserNotFoundException();
    }

    @Override
    public User getUserByIndex(Integer index) {
        if (index > UserCount) {
            throw new UserNotFoundException();
        }
        return Users[index];
    }

    @Override
    public Integer getUserCount() {
        return UserCount;
    }

    @Override 
    public User[] getUsers() {
        return Users;
    }
}
