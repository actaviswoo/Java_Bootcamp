public class User {
    private Integer Identifier;
    private String Name;
    private Integer Balance;
    private TransactionsLinkedList TransactionsLinkedList;

    public Integer getIdentifier() {
        return Identifier;
    }
    public String getName() {
        return Name;
    }
    public Integer getBalance() {
        return Balance;
    }
    public TransactionsLinkedList getTransactionsLinkedList() {
        return TransactionsLinkedList;
    }
    public void setIdentifier(Integer indentifier) {
        Identifier = indentifier;
    }
    public void setName(String name) {
        Name = name;
    }
    public void setBalance(Integer balance) {
        Balance = balance;
    }
    public void setTransactionLinkedList(TransactionsLinkedList transactionsLinkedList) {
        TransactionsLinkedList = transactionsLinkedList;
    }

    public User(String name, Integer balance) {
        if (balance < 0) {
            throw new UserInitException();
        } else {
            Identifier = UserIdsGenerator.getInstance().generateId();
            Name = name;
            Balance = balance;
            TransactionsLinkedList = new TransactionsLinkedList();
        }
    }

    @Override
    public String toString() {
        return "[name:" + Name + "][id:" + Identifier + "][" + "[balance:" + Balance + "]";
    }
}
