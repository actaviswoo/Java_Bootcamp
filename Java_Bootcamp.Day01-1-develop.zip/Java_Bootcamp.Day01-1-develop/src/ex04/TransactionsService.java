import java.util.UUID;

public class TransactionsService {
    private UsersList UsersList = new UsersArrayList();
    
    TransactionsService() {}

    public UsersList getUsersList() {
        return UsersList;
    }
    public void setUsersList(UsersList userList) {
        UsersList = userList;
    }

    public void addUser(User user) {
        UsersList.addUser(user);
    }

    public User getUserBalance(User user) {
        return UsersList.getUserById(user.getIdentifier());
    }

    public void removeTransactionById(UUID transactionIdentifier, int userIdentifier) {
        UsersList.getUserById(userIdentifier).getTransactionsLinkedList().removeTransaction(transactionIdentifier);
    }

    public void doTransaction(Integer senderId, Integer recipientId, Integer transferAmount) {
        User sender = UsersList.getUserById(senderId);
        User recipient = UsersList.getUserById(recipientId);
        if (senderId == recipientId) {
            throw new IllegalTransactionService();
        }
        Transaction transaction = new Transaction(recipient, sender, transferAmount);
    }

    public Transaction[] getUnpairedTransactions() {
        int flag = 0;
        TransactionsLinkedList unpairedTransactions = new TransactionsLinkedList();
        Transaction[] allTransactions = getAllTransactions();
        for (int i = 0; i < allTransactions.length; i++) {
            flag = 0;
            for (int j = 0; j < allTransactions.length; j++) {
                if (j == i) {
                    continue;
                }
                if (allTransactions[i].getIdentifier() == allTransactions[j].getIdentifier()) {
                    flag = 1;
                    break;
                }
            }
            if (flag == 0) unpairedTransactions.addTransaction(allTransactions[i]);
        }
        return unpairedTransactions.toArray();
    }
    private Transaction[] getAllTransactions() {
        TransactionsLinkedList allTransactions = new TransactionsLinkedList();
        for (User user : UsersList.getUsers()) {
            if (user != null && user.getTransactionsLinkedList().getSize() != 0) {
                for (Transaction transaction : user.getTransactionsLinkedList().toArray()) {
                    allTransactions.addTransaction(transaction);
                }
            }
        }
        return allTransactions.toArray();
    }
}