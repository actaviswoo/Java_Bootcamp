public class Program {
    public static void main(String[] args) {
        User a = new User("a", 1000);
        User b = new User("b", 1000);
        User c = new User("c", 1000);
        User d = new User("d", 1000);
        TransactionsService transactionsService = new TransactionsService();
        transactionsService.addUser(a);
        transactionsService.addUser(b);
        transactionsService.addUser(c);
        transactionsService.addUser(d);
        transactionsService.doTransaction(a.getIdentifier(), b.getIdentifier(), 400);
        transactionsService.doTransaction(b.getIdentifier(), c.getIdentifier(), 300);
        transactionsService.doTransaction(c.getIdentifier(), d.getIdentifier(), -200);
        transactionsService.doTransaction(d.getIdentifier(), a.getIdentifier(), -100);
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        for (Transaction i : a.getTransactionsLinkedList().toArray()) {
            System.out.println(i.getIdentifier());
        } 
        transactionsService.removeTransactionById(a.getTransactionsLinkedList().toArray()[0].getIdentifier(), a.getIdentifier());
        transactionsService.removeTransactionById(d.getTransactionsLinkedList().toArray()[1].getIdentifier(), d.getIdentifier());
        for (Transaction i : a.getTransactionsLinkedList().toArray()) {
            System.out.println(i.getIdentifier());
        } 
        for (Transaction transaction : transactionsService.getUnpairedTransactions()) {
            transaction.printConsole();
        }
    }
}