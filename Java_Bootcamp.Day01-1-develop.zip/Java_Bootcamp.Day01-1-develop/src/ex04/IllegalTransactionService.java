public class IllegalTransactionService extends RuntimeException {
    public IllegalTransactionService() {
        super("error");
    }
}
