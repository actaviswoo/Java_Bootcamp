package edu.school21.sockets.server;

import edu.school21.sockets.config.ApplicationConfig;
import edu.school21.sockets.models.User;
import edu.school21.sockets.services.UsersService;
import edu.school21.sockets.services.UsersServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component
public class Server {
    private Socket socket;
    private ServerSocket serverSocket;
    private AnnotationConfigApplicationContext context;
    private UsersService service;
    private static List<UserConnection> connectionList = new ArrayList<>();

    @Autowired
    public Server(int port) throws IOException {
        this.serverSocket = new ServerSocket(port);
        System.out.println("[SERVER IS RUNNING]");
    }

    public void start() {
        try {
            context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
            service = context.getBean(UsersServiceImpl.class);
            while(true) {
                socket = serverSocket.accept();
                UserConnection userConnection = new UserConnection(socket, service);
                connectionList.add(userConnection);
                userConnection.start();
            }
        } catch (IOException exception) {
            System.err.println(exception.getMessage());
            System.exit(-1);
        }
    }

    public static void refuseConnection(UserConnection connection) {
        connectionList.remove(connection);
    }

    public static void sendMessageToChat(String message, String username, UserConnection connectionCurrent) throws IOException {
        Long chatId = connectionCurrent.getChatId();
        for(UserConnection connection : connectionList) {
            if(!connection.equals(connectionCurrent) &&
                    Objects.equals(connection.getChatId(), chatId)) {
                connection.sendClientMessage(username + ": " + message);
            }
        }
    }
}

