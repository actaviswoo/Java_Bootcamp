package edu.school21.sockets.repositories;

import edu.school21.sockets.models.Message;
import edu.school21.sockets.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.List;

@Component
public class MessageRepositoryImpl implements MessageRepository {

    private static JdbcTemplate jdbcTemplate;

    @Autowired
    public MessageRepositoryImpl(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
        createTable();
    }

    private void createTable() {
        jdbcTemplate.execute(
                "CREATE TABLE IF NOT EXISTS Chat.Messages (\n" +
                "id SERIAL PRIMARY KEY,\n" +
                "owner INT REFERENCES Chat.Users(id) NOT NULL NOT NULL,\n" +
                "text_ TEXT NOT NULL,\n" +
                "dateTime timestamp default CURRENT_TIMESTAMP\n" +
                ");");

    }

    @Override
    public Message findById(Long id) {
        String query = "SELECT * FROM Chat.Messages WHERE id = " + id;
        Message message = jdbcTemplate.queryForObject(query, new BeanPropertyRowMapper<>(Message.class));
        return message;
    }

    @Override
    public List<Message> findAll() {
        String query = "SELECT * FROM Chat.Messages";
        List<Message> messages = jdbcTemplate.query(query, new BeanPropertyRowMapper<>(Message.class));
        return messages;
    }

    @Override
    public void save(Message entity) {
        String query = "INSERT INTO Chat.Messages(owner, text_) VALUES('" + entity.getOwner() + "', '" + entity.getText() + "')";
        jdbcTemplate.update(query);
    }

    @Override
    public void update(Message entity) {
        jdbcTemplate.update("UPDATE Chat.Messages SET ownerId = ?, messageText = ?, dateTime = ? WHERE id = ?",
                entity.getOwner(),
                entity.getText(),
                entity.getLocalDateTime(),
                entity.getId());
    }

    @Override
    public void delete(Long id) {
        String query = "DELETE FROM Chat.Messages WHERE id = " + id;
        jdbcTemplate.update(query);
    }


}