package edu.school21.sockets.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

import java.time.LocalDateTime;

@AllArgsConstructor
@Data
@ToString
public class Message {
    private Long id;
    private Long owner;
    private String text;
    private LocalDateTime localDateTime;

    public Message(String text, Long owner) {
        this.text = text;
        this.owner = owner;
    }
    public Message() {

    }
}
