package edu.school21.sockets.server;

import edu.school21.sockets.models.User;
import edu.school21.sockets.services.UsersService;
import lombok.EqualsAndHashCode;

import java.io.*;
import java.net.Socket;

@EqualsAndHashCode
public class UserConnection extends Thread {
    private Socket socket;
    private UsersService usersService;
    private BufferedReader input;
    private BufferedWriter out;
    private Long chatId;
    private Long userId;
    private String login;

    public UserConnection(Socket socket, UsersService usersService) throws IOException {
        this.socket = socket;
        this.usersService = usersService;
        input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
    }

    @Override
    public void run() {
        System.out.println("[CLIENT CONNECTED]");
        try {
            if (getClientAction()) {
                System.out.println("[SUCCESSFUL]");
            } else {
                System.out.println("[FAILURE]");
            }
        } catch (IOException exception) {
            System.err.println(exception.getMessage());
            System.exit(-1);
        }
    }

    private boolean getClientAction() throws IOException {
        boolean result = false;
        sendClientMessage("Enter command(signUp, signIn, exit)");
        String message = input.readLine();
        if (message != null) {
            if (message.equalsIgnoreCase("signUp")) {
                result = signUp();
            } else if (message.equalsIgnoreCase("signIn")) {
                result = signIn();
            } else if (message.equalsIgnoreCase("exit")) {
                refuseConnection();
                result = false;
            }

        }
        return result;
    }

    private boolean signUp() {
        try {
            sendClientMessage("Enter username:");
            login = input.readLine();
            sendClientMessage("Enter password:");
            String password = input.readLine();
            if((login == null || login.isEmpty()) || (password == null || password.isEmpty())) {
                sendClientMessage("Wrong data for signUp");
            } else {
                if(!usersService.signUp(login, password)) {
                    sendClientMessage("Failed! User with this login already exists");
                } else {
                    sendClientMessage("Successful!");
                    return true;
                }
            }
        } catch (IOException exception) {
            System.err.println(exception.getMessage());
            System.exit(-1);
        }
        return false;
    }

    private boolean signIn() {
        try {
            sendClientMessage("Enter username:");
            login = input.readLine();
            sendClientMessage("Enter password:");
            String password = input.readLine();
            if((userId = usersService.signIn(login, password)) != null) {
                sendClientMessage("Successful!");
                startMessaging();
                return true;
            } else {
                sendClientMessage("Failed!");
            }
        } catch (IOException exception) {
            System.err.println(exception.getMessage());
            System.exit(-1);
        }
        return false;
    }


    private void refuseConnection() throws IOException {
        Server.refuseConnection(this);
        socket.close();
        input.close();
        out.close();
    }

    public void sendClientMessage(String message) throws IOException {
        out.write(message);
        out.newLine();
        out.flush();
    }

    private void startMessaging() {
        try {
            chatId = 1L;
            sendClientMessage("Start messaging:");
            String message = "";
            while (!(message = input.readLine()).equalsIgnoreCase("exit")) {
                usersService.saveMessage(message, userId);
                Server.sendMessageToChat(message, login, this);
            }
            sendClientMessage("You have left the chat!");
            refuseConnection();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    public Long getChatId() {
        return chatId;
    }

    public UsersService getUsersService() {
        return usersService;
    }
}
