package edu.school21.sockets.repositories;


import edu.school21.sockets.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Types;
import java.util.List;
import java.util.Optional;

@Component
public class UsersRepositoryImpl implements UsersRepository {
    private static JdbcTemplate jdbcTemplate;

    @Autowired
    public UsersRepositoryImpl(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
        createTable();
    }

    private void createTable() {
        jdbcTemplate.execute("CREATE SCHEMA IF NOT EXISTS Chat;\n" +
                "CREATE TABLE IF NOT EXISTS Chat.Users (\n" +
                "id SERIAL PRIMARY KEY,\n" +
                "login VARCHAR(50) NOT NULL UNIQUE,\n" +
                "password VARCHAR(1000) NOT NULL\n" +
                ");");
    }

    @Override
    public User findById(Long id) {
        String query = "SELECT * FROM Chat.Users WHERE id = " + id;
        User user = jdbcTemplate.queryForObject(query, new BeanPropertyRowMapper<>(User.class));
        return user;
    }

    @Override
    public List<User> findAll() {
        String query = "SELECT * FROM Chat.Users";
        List<User> users = jdbcTemplate.query(query, new BeanPropertyRowMapper<>(User.class));
        return users;
    }

    @Override
    public void save(User entity) {
        String query = "INSERT INTO Chat.Users(login, password) VALUES('" + entity.getLogin() + "', '" + entity.getPassword() + "')";
        jdbcTemplate.update(query);
    }

    @Override
    public void update(User entity) {
        String query = "UPDATE Chat.Users SET login = '"  + entity.getLogin() + "', password = '" + entity.getPassword() + "' WHERE id = " + entity.getId();
        jdbcTemplate.update(query);
    }

    @Override
    public void delete(Long id) {
        String query = "DELETE FROM Chat.Users WHERE id = " + id;
        jdbcTemplate.update(query);
    }

    @Override
    public Optional<User> findByLogin(String login) {
        if(login == null || login.isEmpty()) {
            return Optional.empty();
        }
        Optional<User> user = Optional.ofNullable(jdbcTemplate.query("SELECT * FROM Chat.Users WHERE login=?",
                new Object[]{login},
                new int[]{Types.VARCHAR},
                new BeanPropertyRowMapper<>(User.class)).stream().findAny().orElse(null));
        return user;
    }

}
