package edu.school21.sockets.repositories;

import edu.school21.sockets.models.Message;

public interface MessageRepository extends CrudRepository<Message> {
}
