package edu.school21.sockets.server;

import edu.school21.sockets.models.User;
import edu.school21.sockets.services.UsersService;

import java.io.*;
import java.net.Socket;

public class UserConnection extends Thread {
    private Socket socket;
    private UsersService usersService;
    private BufferedReader input;
    private BufferedWriter out;
    private String status;

    public UserConnection(Socket socket, UsersService usersService) throws IOException {
        this.socket = socket;
        this.usersService = usersService;
        input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
    }

    @Override
    public void run() {
        System.out.println("[CLIENT CONNECTED]");
        try {
            if (getClientAction()) {
                System.out.println("[SUCCESSFUL]");
            } else {
                System.out.println("[FAILURE]");
            }
        } catch (IOException exception) {
            System.err.println(exception.getMessage());
            System.exit(-1);
        }
    }

    private boolean getClientAction() throws IOException {
        sendClientMessage("Enter command");
        String message = input.readLine();
        if (message.equalsIgnoreCase("signup")) {
            sendClientMessage("Enter login");
            String login = input.readLine();
            sendClientMessage("Enter password");
            String password = input.readLine();
            usersService.signUp(new User(0L, login, password));
            sendClientMessage("Successful");
            refuseConnection();
            return true;
        }
        return false;
    }

    private void refuseConnection() throws IOException {
        socket.close();
        input.close();
        out.close();
    }

    private void sendClientMessage(String message) throws IOException {
        out.write(message);
        out.newLine();
        out.flush();
    }

    public UsersService getUsersService() {
        return usersService;
    }
}
