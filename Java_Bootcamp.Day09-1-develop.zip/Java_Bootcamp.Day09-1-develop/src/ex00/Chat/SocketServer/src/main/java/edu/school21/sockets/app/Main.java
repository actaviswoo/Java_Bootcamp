package edu.school21.sockets.app;

import edu.school21.sockets.server.Server;

import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        if(args.length == 1 && args[0].matches("--server-port=\\d++")) {
            try {
                Server server = new Server(Integer.parseInt(args[0].split("=")[1]));
                server.start();
            } catch (IOException exception) {
                System.err.println(exception.getMessage());
                System.exit(-1);
            }
        }
    }
}
