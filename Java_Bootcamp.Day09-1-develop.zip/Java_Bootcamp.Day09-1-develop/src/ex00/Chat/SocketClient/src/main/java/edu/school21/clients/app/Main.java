package edu.school21.clients.app;

import edu.school21.clients.client.Client;

import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        if(args.length == 1 && args[0].matches("--port=\\d++")){
            try {
                Client client = new Client(Integer.parseInt(args[0].split("=")[1]));
                client.start();
            } catch (IOException exception) {
                System.err.println(exception.getMessage());
                System.exit(-1);
            }
        }
    }
}
