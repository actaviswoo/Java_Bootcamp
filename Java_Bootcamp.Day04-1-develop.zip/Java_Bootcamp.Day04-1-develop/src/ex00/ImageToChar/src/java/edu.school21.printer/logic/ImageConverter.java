package edu.school21.printer.logic;

import java.awt.image.BufferedImage;
import java.awt.Color;
public class ImageConverter {
    private String black;
    private String white;
    private BufferedImage image;
    public ImageConverter(String black, String white, BufferedImage image) {
        this.black = black;
        this.white = white;
        this.image = image;
    }

    @Override
    public String toString() {
        Color color;
        int height = image.getHeight();
        int width = image.getWidth();
        String result = "";
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                color = new Color(image.getRGB(j, i));
                if (color.equals(Color.WHITE)) {
                    result += white;
                } else if (color.equals(Color.BLACK)) {
                    result += black;
                }
            }
            result += "\n";
        }
        return result;
    }
}
