*in directory ImageToChar*
COMPILE
mkdir target && cd target && mkdir classes && cd .. && javac -d target/classes src/java/edu.school21.printer/*/*.java 
OR
mvn compile -f pom.xml

*change args*
RUN
java -cp target/classes edu.school21.printer.app.Program --black=# --white=. --imagePath=/Users/argoniaz/Desktop/Java_Bootcamp.Day04-1/src/ex00/ImageToChar/src/resources/image.bmp
OR
mvn exec:java -Dexec.mainClass="edu.school21.printer.app.Program" -Dexec.args="--black=# --white=. --imagePath=/Users/argoniaz/Desktop/Java_Bootcamp.Day04-1/src/ex00/ImageToChar/src/resources/image.bmp"

CLEAN
mvn clean -f pom.xml

*for install maven*
https://maven.apache.org/download.cgi

export M2_HOME="/Users/argoniaz/Downloads/apache-maven-x.x.x"
PATH="${M2_HOME}/bin:${PATH}"
export PATH