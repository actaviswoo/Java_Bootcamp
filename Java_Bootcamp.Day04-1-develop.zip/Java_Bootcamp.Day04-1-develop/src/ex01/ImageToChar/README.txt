*in directory ImageToChar*
CREATE PACKAGE
mvn package -f pom.xml

*change args*
RUN
chmod u+x target/ImageToChar-1.0-SNAPSHOT.jar
java -jar target/ImageToChar-1.0-SNAPSHOT.jar --black=# --white=.

CLEAN
mvn clean -f pom.xml

*for install maven*
https://maven.apache.org/download.cgi

export M2_HOME="/Users/argoniaz/Downloads/apache-maven-x.x.x"
PATH="${M2_HOME}/bin:${PATH}"
export PATH