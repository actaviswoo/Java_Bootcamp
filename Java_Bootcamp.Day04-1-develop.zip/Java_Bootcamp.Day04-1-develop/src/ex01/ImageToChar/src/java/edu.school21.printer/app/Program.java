package edu.school21.printer.app;

import edu.school21.printer.logic.ImageConverter;

import java.io.InputStream;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
public class Program {
    public static void main(String args[]) {
        try {
            checkArgs(args);
            String black = args[0].split("=")[1];
            String white = args[1].split("=")[1];
            InputStream inputStream = Program.class.getResourceAsStream("/resources/image.bmp");
            BufferedImage image = ImageIO.read(inputStream);
            checkSize(image);
            ImageConverter converter = new ImageConverter(black, white, image);
            System.out.println(converter.toString());
        } catch (IndexOutOfBoundsException e) {
            System.err.println("wrong input");
            System.exit(1);
        } catch (IOException e) {
            System.err.println("image not found");
            System.exit(1);
        } catch (IllegalArgumentException e) {
            System.err.println("wrong");
            System.exit(1);
        }
    }

    public static void checkArgs(String args[]) {
        if (args.length != 2
            || !args[0].startsWith("--black=")
            || !args[1].startsWith("--white=")
            || args[0].split("=")[1].length() != 1
            || args[1].split("=")[1].length() != 1) {
            System.err.println("wrong input");
            System.exit(1);
        }
    }

    public static void checkSize(BufferedImage image) {
        if (!(image.getHeight() == 16 && image.getWidth() == 16)) {
            System.err.println("wrong size");
        }
    }
}