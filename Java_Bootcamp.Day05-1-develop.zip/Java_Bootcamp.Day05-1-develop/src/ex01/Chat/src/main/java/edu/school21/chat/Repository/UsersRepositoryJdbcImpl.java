package edu.school21.chat.Repository;

import edu.school21.chat.Models.User;

import javax.sql.DataSource;
import java.sql.*;
import java.util.Optional;

public class UsersRepositoryJdbcImpl implements UsersRepository {
    private static DataSource dataSource;

    public UsersRepositoryJdbcImpl(DataSource dataSource) throws SQLException {
        UsersRepositoryJdbcImpl.dataSource = dataSource;
    }

    public Optional<User> findById(Long id) throws SQLException {
        try {
            Connection connection = dataSource.getConnection();
            PreparedStatement userStatement = connection.prepareStatement("SELECT * FROM chat.user WHERE id = " + id);
            ResultSet userSet = userStatement.executeQuery();
            if (userSet.next()) {
                long userId = userSet.getLong(1);
                String userLogin = userSet.getString(2);
                String userPassword = userSet.getString(3);
                Optional <User> optionalUser = Optional.of(new User(userId, userLogin, userPassword, null, null));
                return optionalUser;
            }
        } catch (SQLException exception) {
            System.err.println(exception.getMessage());
        }
        return Optional.empty();
    }
}
