package edu.school21.chat.Repository;

import com.zaxxer.hikari.HikariDataSource;
import edu.school21.chat.Models.*;
import java.sql.*;
import java.util.Optional;
import java.util.List;
import javax.sql.DataSource;


public class MessagesRepositoryJdbcImpl implements MessagesRepository {
    private static DataSource dataSource;

    public MessagesRepositoryJdbcImpl(DataSource dataSource) throws SQLException {
        MessagesRepositoryJdbcImpl.dataSource = dataSource;
    }

    @Override
    public Optional<Message> findById(Long id) throws SQLException {
        try {
            Connection connection = dataSource.getConnection();
            PreparedStatement messageStatement = connection.prepareStatement("SELECT * FROM chat.message WHERE id = " + id);
            ResultSet messageSet = messageStatement.executeQuery();
            if (messageSet.next()) {
                long messageId = messageSet.getLong(1);
                UsersRepository usersRepository = new UsersRepositoryJdbcImpl(dataSource);
                User messageAuthor = usersRepository.findById(messageSet.getLong(2)).orElse(new User());
                ChatroomsRepository chatroomsRepository = new ChatroomsRepositoryJdbcImpl(dataSource);
                Chatroom messageChatroom = chatroomsRepository.findById(messageSet.getLong(3)).orElse(new Chatroom());
                String messageText = messageSet.getString(4);
                Timestamp messageTimestamp = new Timestamp(1);
                Optional <Message> optionalMessage = Optional.of(new Message(messageId, messageAuthor, messageChatroom, messageText, messageTimestamp));
                return optionalMessage;
            }
        } catch (SQLException exception) {
            System.err.println(exception.getMessage());
        }
        return Optional.empty();
    }
}
