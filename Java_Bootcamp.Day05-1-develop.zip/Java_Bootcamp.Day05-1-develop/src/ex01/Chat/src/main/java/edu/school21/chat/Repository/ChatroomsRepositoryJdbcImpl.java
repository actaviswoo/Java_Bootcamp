package edu.school21.chat.Repository;

import edu.school21.chat.Models.Chatroom;
import edu.school21.chat.Models.User;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

public class ChatroomsRepositoryJdbcImpl implements ChatroomsRepository {
    private static DataSource dataSource;

    public ChatroomsRepositoryJdbcImpl(DataSource dataSource) throws SQLException {
        ChatroomsRepositoryJdbcImpl.dataSource = dataSource;
    }

    @Override
    public Optional<Chatroom> findById(Long id) throws SQLException {
        try {
            Connection connection = dataSource.getConnection();
            PreparedStatement chatroomStatement = connection.prepareStatement("SELECT * FROM chat.chatroom WHERE id = " + id);
            ResultSet chatroomSet = chatroomStatement.executeQuery();
            if (chatroomSet.next()) {
                long chatroomId = chatroomSet.getLong(1);
                String chatroomName = chatroomSet.getString(2);
                UsersRepository usersRepository = new UsersRepositoryJdbcImpl(dataSource);
                User chatroomOwner = usersRepository.findById(chatroomSet.getLong(3)).orElse(new User());
                Optional <Chatroom> optionalChatroom = Optional.of(new Chatroom(chatroomId, chatroomName, chatroomOwner, null));
                return optionalChatroom;
            }
        } catch (SQLException exception) {
            System.err.println(exception.getMessage());
        }
        return Optional.empty();
    }
}
