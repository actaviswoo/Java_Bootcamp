package edu.school21.chat.Main;

import edu.school21.chat.Models.*;
import com.zaxxer.hikari.HikariConfig;
import edu.school21.chat.Repository.*;

import javax.sql.DataSource;
import java.sql.*;
import java.util.Scanner;
import com.zaxxer.hikari.HikariDataSource;


public class Program {
    private static final String url = "jdbc:postgresql://localhost:6666/postgres";
    private static final String username = "postgres";
    private static final String password = " ";

    public static void main(String[] args) {
        try {
            HikariConfig hikariConfig = new HikariConfig();
            hikariConfig.setJdbcUrl(url);
            hikariConfig.setUsername(username);
            hikariConfig.setPassword(password);
            DataSource dataSource = new HikariDataSource(hikariConfig);
            MessagesRepository messagesRepository = new MessagesRepositoryJdbcImpl(dataSource);
            System.out.print("Enter a message ID\n-->");
            String line = "";
            Scanner scanner = new Scanner(System.in);
            line = scanner.next();
            long id = Long.parseLong(line.trim());
            Message message = messagesRepository.findById(id).orElse(new Message());
            System.out.println(message);
        } catch (SQLException exception) {
            System.err.println(exception.getMessage());
        }
    }

}