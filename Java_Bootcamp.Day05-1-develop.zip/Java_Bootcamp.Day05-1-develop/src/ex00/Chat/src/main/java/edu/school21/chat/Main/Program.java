package edu.school21.chat.Main;

import edu.school21.chat.Models.*;
import java.sql.*;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Program {
    private static final String url = "jdbc:postgresql://127.0.0.1:6666/postgres";
    private static final String username = "postgres";
    private static final String password = " ";

    public static void main(String[] args) {
        try(Connection connection = DriverManager.getConnection(url, username, password)) {
            userOut(connection);
            chatroomOut(connection);
            messageOut(connection);
        } catch (SQLException exception) {
            System.err.println(exception.getMessage());
        }
    }

    public static void userOut(Connection connection) throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Chat.user", ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        ResultSet set = preparedStatement.executeQuery();
        while(set.next()) {
            System.out.printf("%4s|%20s|%20s\n",set.getString(1), set.getString(2), set.getString(3));
        }
        set.beforeFirst();
        List<User> listUser = new ArrayList<>();
        while(set.next()) {
            User modelUser = new User(set.getLong(1), set.getString(2), set.getString(3), null, null);
            listUser.add(modelUser);
        }
        for (int i = 0; i < listUser.size(); i++) {
            System.out.println(listUser.get(i).toString());
        }
    }

    public static void chatroomOut(Connection connection) throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Chat.chatroom", ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        ResultSet set = preparedStatement.executeQuery();
        while(set.next()) {
            System.out.printf("%4s|%20s|%4s\n",set.getString(1), set.getString(2), set.getString(3));
        }
        set.beforeFirst();
        List<Chatroom> listChatroom = new ArrayList<>();
        while(set.next()) {
            PreparedStatement userStatement = connection.prepareStatement("SELECT * FROM Chat.user WHERE id = " + set.getLong(3));
            ResultSet userSet = userStatement.executeQuery();
            userSet.next();
            User modelUser = new User(userSet.getLong(1), userSet.getString(2), userSet.getString(3), null, null);
            Chatroom modelChatroom = new Chatroom(set.getLong(1), set.getString(2), modelUser, null);
            listChatroom.add(modelChatroom);
            userSet.close();
            userStatement.close();
        }
        for (int i = 0; i < listChatroom.size(); i++) {
            System.out.println(listChatroom.get(i).toString());
        }
    }

    public static void messageOut(Connection connection) throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Chat.message", ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        ResultSet set = preparedStatement.executeQuery();
        while(set.next()) {
            System.out.printf("%4s|%4s|%4s|%100s|%35s\n",set.getString(1), set.getString(2), set.getString(3), set.getString(4), set.getString(5));
        }
        set.beforeFirst();
        List<Message> listMessage = new ArrayList<>();
        while(set.next()) {
            try {
                String dateString = set.getString(5);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS");
                Date date = sdf.parse(dateString);
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(date);
                PreparedStatement userStatement = connection.prepareStatement("SELECT * FROM Chat.user WHERE id = " + set.getLong(2));
                PreparedStatement chatroomStatement = connection.prepareStatement("SELECT * FROM Chat.chatroom WHERE id = " + set.getLong(3));
                ResultSet userSet = userStatement.executeQuery();
                ResultSet chatroomSet = chatroomStatement.executeQuery();
                userSet.next();
                chatroomSet.next() ;
                PreparedStatement userChatroomStatement = connection.prepareStatement("SELECT * FROM Chat.user WHERE id = " + chatroomSet.getLong(3));
                ResultSet userChatroomSet = userChatroomStatement.executeQuery();
                userChatroomSet.next();
                User modelUser = new User(userSet.getLong(1), userSet.getString(2), userSet.getString(3), null, null);
                User modelChatroomUser = new User(userChatroomSet.getLong(1), userChatroomSet.getString(2), userChatroomSet.getString(3), null, null);
                Chatroom modelChatroom = new Chatroom(chatroomSet.getLong(1), chatroomSet.getString(2), modelChatroomUser, null);
                Message modelMessage = new Message(set.getLong(1), modelUser, modelChatroom, set.getString(4), calendar);
                listMessage.add(modelMessage);
                userStatement.close();
                chatroomStatement.close();
                userChatroomStatement.close();
                userSet.close();
                chatroomSet.close();
                userChatroomSet.close();
            } catch (ParseException exception) {
                System.err.println(exception.getMessage());
            }
        }
        for (int i = 0; i < listMessage.size(); i++) {
            System.out.println(listMessage.get(i).toString());
        }
    }
}
