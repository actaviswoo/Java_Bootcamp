DROP SCHEMA IF EXISTS Chat CASCADE;
CREATE SCHEMA IF NOT EXISTS Chat;

CREATE TABLE IF NOT EXISTS Chat.user (
    id                  INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    login               VARCHAR(50) UNIQUE NOT NULL,
    password            VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS Chat.chatroom (
    id                  INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    name                VARCHAR(50) UNIQUE NOT NULL,
    owner               INTEGER REFERENCES Chat.user(id) NOT NULL
);

CREATE TABLE IF NOT EXISTS Chat.message (
    id                  INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    author              INTEGER REFERENCES Chat.user(id) NOT NULL,
    room                INTEGER REFERENCES Chat.chatroom(id) NOT NULL,
    text                TEXT NOT NULL,
    datetime            TIMESTAMP NOT NULL
);