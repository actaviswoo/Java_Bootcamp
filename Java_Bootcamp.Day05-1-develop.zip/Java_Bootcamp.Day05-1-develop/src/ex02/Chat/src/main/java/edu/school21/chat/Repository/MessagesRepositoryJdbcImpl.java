package edu.school21.chat.Repository;

import com.zaxxer.hikari.HikariDataSource;
import edu.school21.chat.Models.*;
import java.sql.*;
import java.util.Optional;
import java.util.List;
import javax.sql.DataSource;


public class MessagesRepositoryJdbcImpl implements MessagesRepository {
    private static DataSource dataSource;

    public MessagesRepositoryJdbcImpl(DataSource dataSource) throws SQLException {
        MessagesRepositoryJdbcImpl.dataSource = dataSource;
    }

    @Override
    public Optional<Message> findById(Long id) throws SQLException {
        try {
            Connection connection = dataSource.getConnection();
            PreparedStatement messageStatement = connection.prepareStatement("SELECT * FROM chat.message WHERE id = " + id);
            ResultSet messageSet = messageStatement.executeQuery();
            if (messageSet.next()) {
                long messageId = messageSet.getLong(1);
                UsersRepository usersRepository = new UsersRepositoryJdbcImpl(dataSource);
                User messageAuthor = usersRepository.findById(messageSet.getLong(2)).orElse(new User());
                ChatroomsRepository chatroomsRepository = new ChatroomsRepositoryJdbcImpl(dataSource);
                Chatroom messageChatroom = chatroomsRepository.findById(messageSet.getLong(3)).orElse(new Chatroom());
                String messageText = messageSet.getString(4);
                Timestamp messageTimestamp = new Timestamp(1);
                Optional <Message> optionalMessage = Optional.of(new Message(messageId, messageAuthor, messageChatroom, messageText, messageTimestamp));
                return optionalMessage;
            }
        } catch (SQLException exception) {
            System.err.println(exception.getMessage());
        }
        return Optional.empty();
    }

    @Override
    public void save(Message message) throws NotSavedSubEntityException {
        try {
            if(message.getAuthor() == null) {
                throw new NotSavedSubEntityException("Author hasn't supported");
            }
            if(message.getRoom() == null) {
                throw new NotSavedSubEntityException("Chatroom hasn't supported");
            }
            if(message.getText() == null || message.getText().length() < 1) {
                throw new NotSavedSubEntityException("Text hasn't supported");
            }
            if(message.getDatetime() == null) {
                throw new NotSavedSubEntityException("Datetime hasn't supported");
            }
            Connection connection = dataSource.getConnection();
            Statement messageStatement = connection.createStatement();
            String query = "INSERT INTO chat.message(author, room, text, datetime) VALUES (" +
                    message.getAuthor().getId() + ", " +
                    message.getRoom().getId() + ", '" +
                    message.getText() + "', '" +
                    message.getDatetime() + "') RETURNING id";
            ResultSet messageSet = messageStatement.executeQuery(query);
            messageSet.next();
            message.setId(messageSet.getLong(1));
        } catch (SQLException exception) {
            System.err.println(exception.getMessage());
        }
    }
}
