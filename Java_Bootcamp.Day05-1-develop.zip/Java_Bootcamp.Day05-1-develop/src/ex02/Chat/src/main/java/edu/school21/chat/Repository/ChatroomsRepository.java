package edu.school21.chat.Repository;

import edu.school21.chat.Models.Chatroom;
import edu.school21.chat.Models.Message;

import java.sql.SQLException;
import java.util.Optional;

public interface ChatroomsRepository {
    Optional<Chatroom> findById(Long id) throws SQLException;
}
