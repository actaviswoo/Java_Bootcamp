package ex00;

public class Program {
    public static void main(String[] args) {
        try {
            if (args.length != 1 || !args[0].startsWith("--count=")) {
                System.err.println("error");
                System.exit(1);
            }
            Integer count = Integer.parseInt(args[0].split("=")[1]);
            Egg egg = new Egg(count);
            Hen hen = new Hen(count);
            egg.start();
            hen.start();
            for (int i = 0; i < count; i++) {
                System.out.println("Human");
            }
        } catch (NumberFormatException e) {
            System.err.println("error");
            System.exit(1);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.err.println("error");
            System.exit(1);
        }
    }
}