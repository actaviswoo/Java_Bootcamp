package ex02;

public class Program {
    public static int array[];
    public static int sum = 0;
    public static void main(String args[]) {
        try {
            if (args.length != 2 || !args[0].startsWith("--arraySize=") || !args[1].startsWith("--threadsCount=")) {
                System.err.println("error");
                System.exit(1);
            }
            int arraySize = Integer.parseInt(args[0].split("=")[1]);
            int threadsCount = Integer.parseInt(args[1].split("=")[1]);
            if (threadsCount > arraySize || arraySize > 2000000) {
                System.err.println("error");
                System.exit(-1);
            }
            array = new int[arraySize];
            for (int i = 0; i < arraySize; i++) {
                array[i] = (int)(Math.random() * 2000 - 1000);
            }
            int division = (int)Math.ceil((double)(arraySize) / (double)(threadsCount));
            int arraySums[] = new int[threadsCount];
            int resultThread = 0;
            for (int i = 0; i < arraySums.length; i++) {
                SumThread SumThread = new SumThread(i * division, (i + 1) * division - 1);
                SumThread.start();
                SumThread.join();
                arraySums[i] = sum;
                resultThread += arraySums[i];
            }
            for (int i = 0; i < arraySums.length; i++) {
                System.out.println("threas from " + (i * division) + " to " + ((i + 1) * division - 1) + " is " + arraySums[i]);
            }
            System.out.println("thread " + resultThread);

            int result = 0;
            for (int i : array) result = result + i;
            System.out.println("default " + result);

        } catch (NumberFormatException e) {
            System.err.println("error");
            System.exit(1);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.err.println("error");
            System.exit(1);
        } catch (InterruptedException e) {
            System.err.println("error");
            System.exit(1);
        }
    }
}
