package ex02;

public class SumThread extends Thread {
    private int from;
    private int to;

    public SumThread(int From, int To) {
        from = From;
        to = To;
    }

    @Override
    public void run() {
        Program.sum = 0;
        for (int i = from; i <= to; i++) {
            if (i < Program.array.length)
            Program.sum = Program.sum + Program.array[i];
        }
    }
}
