package ex03;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Program {
    public static void main(String[] args) {
        try {
            if (args.length != 1 || !args[0].startsWith("--threadsCount=")) {
                System.err.println("error");
                System.exit(1);
            }
            int threadsCount = Integer.parseInt(args[0].split("=")[1]);
            ThreadDownload[] threads = new ThreadDownload[threadsCount];
            ProducerConsumer producerConsumer = new ProducerConsumer(threadsCount);
            for (int i = 0; i < threadsCount; i++) {
                threads[i] = new ThreadDownload(producerConsumer);
            }
            for (ThreadDownload i : threads) {
                i.start();
            }
        } catch (NumberFormatException e) {
            System.err.println("error");
            System.exit(1);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.err.println("error");
            System.exit(1);
        }  catch (FileNotFoundException e) {
            System.err.println("error");
            System.exit(-1);
        }
    }
}

