package ex03;

import java.io.IOException;
import java.net.MalformedURLException;

public class ThreadDownload extends Thread {
    private ProducerConsumer producerConsumer;
    
    public ThreadDownload(ProducerConsumer ProducerConsumer) {
        producerConsumer = ProducerConsumer;
    }

    @Override
    public void run() {
        try {
            while (producerConsumer.getLastFileNumber() != producerConsumer.getFileListSize()) {
                producerConsumer.downloadFile(getName());
            }
        } catch (MalformedURLException e) {
            System.err.println(e);
        } catch (InterruptedException e) {
            System.err.println(e);
        } catch (IOException e) {
            System.err.println(e);
        }
    }
}
