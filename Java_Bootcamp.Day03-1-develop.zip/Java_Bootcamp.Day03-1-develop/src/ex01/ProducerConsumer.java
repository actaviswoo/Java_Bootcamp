package ex01;

public class ProducerConsumer {
    private static boolean state = true;
    synchronized void produce() throws InterruptedException {
        if (!state) {
            wait();
        }
        System.out.println("Egg");
        state = false;
        notify();
    }
    synchronized void consume() throws InterruptedException {
        if (state) {
            wait();
        }
        System.out.println("Hen");
        state = true;
        notify();
    }
}