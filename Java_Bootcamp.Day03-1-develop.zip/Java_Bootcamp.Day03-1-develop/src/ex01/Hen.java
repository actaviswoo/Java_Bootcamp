package ex01;

public class Hen extends Thread {
    private int count;
    private ProducerConsumer producerConsumer;
    public Hen(int Count, ProducerConsumer ProducerConsumer) {
        count = Count;
        producerConsumer = ProducerConsumer;
    }
    @Override
    public void run() {
        try {
            for (int i = 0; i < count; i++) {
                producerConsumer.consume();
            }
        } catch (InterruptedException e) {
            throw new RuntimeException();
        }
    }
}
