package ex01;

public class Program {
    public static void main(String[] args) {
        try {
            if (args.length != 1 || !args[0].startsWith("--count=")) {
                System.err.println("error");
                System.exit(1);
            }
            Integer count = Integer.parseInt(args[0].split("=")[1]);
            ProducerConsumer producerConsumer = new ProducerConsumer();
            Egg egg = new Egg(count, producerConsumer);
            Hen hen = new Hen(count, producerConsumer);
            egg.start();
            hen.start();
        } catch (NumberFormatException e) {
            System.err.println("error");
            System.exit(1);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.err.println("error");
            System.exit(1);
        } catch (RuntimeException e) {
            System.err.println("error");
            System.exit(1);
        }
    }
}