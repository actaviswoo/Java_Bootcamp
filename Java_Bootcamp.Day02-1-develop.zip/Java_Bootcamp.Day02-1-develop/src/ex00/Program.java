package ex00;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.util.HashMap;
import java.util.Scanner;

public class Program {
    private static String out;
    public static void main(String[] args) {
        HashMap<String, String> map = initSignature();
        compareFile(map);
    }

    public static HashMap<String, String> initSignature() {
        try (FileInputStream inputStream = new FileInputStream("ex00/signatures.txt")) { 
            HashMap<String, String> map = new HashMap<>();
            Scanner scanner = new Scanner(inputStream);
            String line;
            String[] formatLine = new String[2];
            while (scanner.hasNextLine()) {
                line = scanner.nextLine();
                formatLine = line.split(", ");
                map.put(formatLine[0], formatLine[1]);
            }
            return map;
        } catch (FileNotFoundException e) {
            System.out.println(e);
        } catch (IOException e) {
            System.out.println(e);
        }
        return null;
    }

    public static void compareFile(HashMap<String, String> map) {
        try (FileOutputStream outputStream = new FileOutputStream("ex00/result.txt", true)) {
            Scanner scanner = new Scanner(System.in);
            String fileName = "";
            System.out.print("-> ");
            while (!(fileName = scanner.next()).equals("42")) {
                if (existFileInSignatures(map, fileName)) {
                    outputStream.write(out.getBytes());
                    outputStream.write('\n');
                    System.out.println("PROCCESED");
                } else {
                    System.out.println("UNKNOWN");
                }
                System.out.print("-> ");
            }
        } catch (FileNotFoundException e) {
            System.out.println(e);
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    public static boolean existFileInSignatures(HashMap<String, String> map, String fileName) {
        try (FileInputStream inputStream = new FileInputStream(fileName)) {
            StringBuffer buffer = new StringBuffer();
            for (int i = 0; i < 8; i++) {
                buffer.append(String.format("%02X ", inputStream.read()));
            }
            for (String k : map.keySet()) {
                if (buffer.toString().startsWith(map.get(k))) {
                    out = k;
                    return true;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println(e);
        } catch (IOException e) {
            System.out.println(e);
        }
        return false;
    }
}
