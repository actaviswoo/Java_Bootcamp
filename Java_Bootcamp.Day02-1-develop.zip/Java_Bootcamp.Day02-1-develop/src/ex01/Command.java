package ex01;

import java.util.*;
import java.io.*;

public class Command {
    public Command() {}
    
    public double calculateSimilarity(Vector<Integer> vector1, Vector<Integer> vector2) {
        int numerator = 0;
        double denominator = 0;
        int squareSumFirst = 0;
        int squareSumSecond = 0;
        for (int i = 0; i < vector1.size(); i++) {
            numerator += vector1.get(i) * vector2.get(i);
            squareSumFirst += vector1.get(i) * vector1.get(i);
            squareSumSecond += vector2.get(i) * vector2.get(i);
        }
        denominator = Math.sqrt(squareSumFirst) * Math.sqrt(squareSumSecond);
        return numerator / denominator;
    }

    public HashMap<String, Integer> parseFile(String filename, HashMap<String, Integer> uniqueMap) throws FileNotFoundException, IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        HashMap<String, Integer> map = new HashMap<String, Integer>();
        String[] keys;
        while(reader.ready()) {
            keys = reader.readLine().split(" ");
            for (String k : keys) {
                if (map.containsKey(k)) {
                    uniqueMap.put(k, map.get(k) + 1);
                    map.put(k, map.get(k) + 1);
                } else {
                    uniqueMap.put(k, 1);
                    map.put(k, 1);
                }
            }
        }
        reader.close();
        return map;
    }

    public HashMap<String, Integer> sortMap(HashMap<String, Integer> uniqueMap) {
        HashMap<String, Integer> sortedMap = new HashMap<>();
        ArrayList<Map.Entry<String, Integer>> list = new ArrayList<>();
        for (Map.Entry<String, Integer> i : uniqueMap.entrySet()) {
            list.add(i);
        }
        list.sort(Map.Entry.comparingByValue(Comparator.reverseOrder()));
        for (Map.Entry<String, Integer> i : list) {
            sortedMap.put(i.getKey(), i.getValue());
        }
        return sortedMap;
    }

    public Vector<Integer> createVector(HashMap<String, Integer> map, HashMap<String, Integer> sortedMap) {
        Vector<Integer> vector = new Vector<>();
        for (String key : sortedMap.keySet()) {
            if (map.containsKey(key)) {
                vector.add(map.get(key));
            } else {
                vector.add(0);
            }
        }
        return vector;
    }

    public void saveFile(HashMap<String, Integer> commonMap) throws FileNotFoundException, IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter("ex01/dictionary.txt"));
        writer.write(commonMap.toString());
        writer.close();
    }
}
