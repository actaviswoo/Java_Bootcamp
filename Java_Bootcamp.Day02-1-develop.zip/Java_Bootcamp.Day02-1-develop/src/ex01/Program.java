package ex01;

import java.util.HashMap;

import java.io.*;
import java.util.*;
public class Program {
    public static void main(String args[]) {
        if (args.length != 2) {
            System.err.println("input files");
            System.exit(-1);
        }
        HashMap<String, Integer> uniqueMap = new HashMap<String, Integer>();
        Command command = new Command();
        try {
            HashMap<String, Integer> firstMap = command.parseFile(args[0], uniqueMap);
            HashMap<String, Integer> secondMap = command.parseFile(args[1], uniqueMap);
            if (firstMap.size() == 0 || secondMap.size() == 0) {
                System.err.println("empty file");
                System.exit(-1);
            }
            HashMap<String, Integer> sortedMap = command.sortMap(uniqueMap);
            command.saveFile(sortedMap);
            Vector<Integer> firstVector = command.createVector(firstMap, sortedMap);
            Vector<Integer> secondVector = command.createVector(secondMap, sortedMap);
            double similarity = command.calculateSimilarity(firstVector, secondVector);
            System.out.println(Math.floor(similarity * 100) / 100);
        } catch (FileNotFoundException e) {
            System.err.println("File not found");
        } catch (IOException e) {
            System.err.println(e);
        }
    }
}