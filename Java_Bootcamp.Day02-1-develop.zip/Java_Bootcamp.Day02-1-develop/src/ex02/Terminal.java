package ex02;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;

class NotDirectoryException extends RuntimeException {}

public class Terminal {
    private File folder;
    private Scanner scanner;

    public Terminal(String path) {
        folder = new File(path);
        if (!folder.isDirectory()) {
            throw new NotDirectoryException();
        }
        scanner = new Scanner(System.in);
    }

    public void start() {
        System.out.println(folder.toPath());
        String command;
        while (true) {
            System.out.print(folder.getAbsolutePath() + " $ ");
            command = scanner.next();
            switch (command) {
                case "cd":
                    changeDirectory();
                    break;
                case "ls":
                    list();
                    break;
                case "mv":
                    move();
                    break;
                case "exit":
                    System.exit(0);
                default:
                    System.out.println("command not found: " + command);
                    break;
            }
        }
    }

    public void changeDirectory() {
        if (scanner.hasNext()) {
            String newPath = scanner.next();
            if (newPath.equals("..")) {
                String parentPath = folder.getAbsoluteFile().getParent();
                if (parentPath != null) {
                    folder = new File(parentPath);
                } else {
                    System.out.println("rooted directory");
                }
            } else {
                File newFile = new File(folder, newPath);
                if (newFile.isDirectory()) {
                    folder = newFile;
                } else {
                    System.out.println(newPath + " is not a valid directory");
                }
            }
        }
    }

    public void list() {
        long size;
        String weight;
        for (File entry : folder.listFiles()) {
            if (entry.isFile()) {
                size = entry.length();
                if (size < 1024) {
                    weight = "bytes";
                } else if (size < 1024 * 1024) {
                    size /= 1024;
                    weight = "KB";
                } else {
                    size /= (1024 * 1024);
                    weight = "MB";
                }
                System.out.println(entry.getName() + ' ' + size + ' ' + weight);
            } else {
                System.out.println(entry.getName());
            }
        }
    } 

    public void move() {
        String oldFileName = scanner.next();
        String newFileName = scanner.next();
        File oldFile = new File(folder, oldFileName);
        File newFile = new File(folder, newFileName);
        if (!oldFile.exists()) {
            System.out.println("File " + oldFileName + " does not exist.");
            return;
        }
        try (InputStream inputStream = new FileInputStream(oldFile);
                OutputStream outputStream = new FileOutputStream(newFile)) {
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
            oldFile.delete();
            System.out.println("File " + oldFileName + " moved to " + newFileName);
        } catch (IOException e) {
            System.out.println("An error occurred while moving the file: " + e.getMessage());
        }
    }
} 
