package ex02;
public class Program {
    public static void main(String args[]) {
        if (args.length != 1 || !args[0].startsWith("--current-folder=")) {
            System.err.println("error");
            System.exit(-1);
        }
        try {
            String absolutePath = args[0].split("=")[1];
            Terminal terminal = new Terminal(absolutePath);
            terminal.start();
        } catch (NotDirectoryException e) {
            System.out.println("not directory");
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("error");
        }
    }
}